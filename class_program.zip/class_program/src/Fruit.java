import javax.xml.bind.SchemaOutputResolver;

/**
 * Created by ATMIYA2020 on 22/07/2017.
 */

public class Fruit {

    public void juice() {
        System.out.println("Every fruit have juice in fruit class");
    }

    public void nojuice() {
        System.out.println("No juice in fruit class");
    }


}
class orange extends Fruit
{
    public void juice()
    {
        System.out.println("Orange class in juice method");
    }

    public void nojuice()
    {
        System.out.println("Orange class in nojuice method");
    }

}

 class banana extends Fruit
{
       public void juice()
       {
           System.out.println("Banana class in juice method");
       }

    public void mango()
    {
        System.out.println("Banana class in mango method");
    }

    public static void main(String args[])
    {
        Fruit f = new banana();
       // Fruit f1= new banana();
        Fruit f1 = new orange();

        f.juice();
        f.nojuice();
        f1.nojuice();

    }
}

