/**
 * Created by ATMIYA2020 on 01/07/2017.
 */
//import java.awt.*;
//import java.awt.Toolkit.*;
public class For_loop {



    public static void main(String args[]) {

        // FOR SINGLE DIMENSION ARRAY //
       // int [] a = {1 ,2,3,4,5,6,7,8,9,10} ;
       // FOR MULTIDIMENSION ARRAY //

        int a[][] = new int[10][10];
        int t=1;

      //  Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        //System.out.println(d.getHeight()+ "height");
       // System.out.println(d.width+ "WIDTH");


        for (int i = 1; i <= a.length; i++)
        {
            for (int j = 1; j <= i; j++)
            {
                      System.out.print(" " + t );
                      t++;
            }
            System.out.println(" ");
        }

    }
}
