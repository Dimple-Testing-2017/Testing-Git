import java.util.Random;
import java.util.Scanner;

/**
 * Created by ATMIYA2020 on 23/07/2017.
 */
public class Piggybank {

   public double deposit = 50.00, withdraw, statement;

    public double deposit( double depositamt)
    {
        deposit = deposit + depositamt;
        return deposit;
    }

    public double withdraw( double deposit,double withdrawamt) {
        if(withdrawamt < deposit ) {
            deposit = deposit-withdrawamt;
            return deposit;
        } else {
            //System.out.println("deposit in wiithdraw methods "+ deposit);
            System.out.println("You don't have enough balance to withdraw money");
             return deposit;
        }
        }

    public void statement()
    {
        System.out.println("Current balance is -->" + deposit);

    }

    public static void main(String args[]) {
        double deposit,withdraw;

        Piggybank piggy = new Piggybank();
        Scanner scanner = new Scanner(System.in);

       System.out.println("Please enter the deposit the Amount -->");
        deposit = scanner.nextDouble();
        deposit = piggy.deposit(deposit);
        piggy.statement();

        System.out.println("Please enter the withdraw  Amount -->");
        withdraw= scanner.nextDouble();
        withdraw = piggy.withdraw(deposit,withdraw);
        piggy.statement();


    }


    }

