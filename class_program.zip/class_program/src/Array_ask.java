/**
 * Created by ATMIYA2020 on 01/07/2017.
 */
public class Array_ask {

        public static void main(String args[]) {

            // FOR SINGLE DIMENSION ARRAY //
            // int [] a = {1 ,2,3,4,5,6,7,8,9,10} ;
            // FOR MULTIDIMENSION ARRAY //

            int a[][] = new int[26][26];

            for (int i = 0; i <= 26; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    System.out.print(" * ");
                }
            System.out.println(" ");
            }

        }
    }
