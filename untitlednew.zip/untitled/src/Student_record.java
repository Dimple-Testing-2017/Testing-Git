/**
 * Created by ATMIYA2020 on 20/06/2017.
 */
public class Student_record {
    // CLASS START FROM HERE //

    // STUDENT METHOD START HERE //
    //  ** NO RETURN TYPE WITH PARAMETER ** //
    public static void student1(String name,int age, int r_no, int maths,int biology,int chemistry )
    {
        int total;
        total = maths + biology + chemistry;
        System.out.println("Student Name is --> " + name);
        System.out.println("Student Roll number is --> " + r_no);
        System.out.println("Student Age is --> " + age);
        System.out.println("------------------------------------------");
        System.out.println("Maths         Biology         Chemistry ");
        System.out.println("------------------------------------------");
        System.out.println(maths + "            " + biology  + "              " + chemistry);
        System.out.println("------------------------------------------");
        System.out.println("Total = "+ total);
     }
    // STUDENT METHOD END HERE  //

    // STUDENT METHOD START HERE //
    // ** NO RETURN TYPE WITHOUT PARAMETER ** //
    public static void student2()
    {
        String name = "Rekha";
        int age = 13, roll_no= 2,maths = 60, biology= 60, chemistry =60, total;
        total = maths + biology + chemistry;
        System.out.println("Student Name is --> " + name);
        System.out.println("Student Roll number is --> " + roll_no);
        System.out.println("Student Age is --> " + age);
        System.out.println("------------------------------------------");
        System.out.println("Maths         Biology         Chemistry ");
        System.out.println("------------------------------------------");
        System.out.println(maths + "            " + biology  + "              " + chemistry);
        System.out.println("------------------------------------------");
        total= maths + biology + chemistry;
        System.out.println("Total = "+ total);

    }
    // STUDENT METHOD END HERE  //

    // STUDENT METHOD START HERE //
    // ** RETURN TYPE WITH  PARAMETER ** //
    public int student3(String name, int age, int roll_no, int m, int b, int c)
    {
        int total = m + b + c;
        System.out.println("Student Name is --> " + name);
        System.out.println("Student Roll number is --> " + roll_no);
        System.out.println("Student Age is --> " + age);
        System.out.println("------------------------------------------");
        System.out.println("Maths         Biology         Chemistry ");
        System.out.println("------------------------------------------");
        System.out.println(m + "            " + b + "              " + c);
        System.out.println("------------------------------------------");
        return total;
        //System.out.println("Total = "+ total);

    }
    // STUDENT METHOD END HERE  //

    // STUDENT METHOD START HERE //
    // ** RETURN TYPE WITHOUT PARAMETER ** //
     public int student4()
    {
        String name = "Natasha";
        int age = 13, roll_no= 4,m = 80, b= 80, c=80, total;
        total = m + b + c;
        System.out.println("Student Name is --> " + name);
        System.out.println("Student Roll number is --> " + roll_no);
        System.out.println("Student Age is --> " + age);
        System.out.println("------------------------------------------");
        System.out.println("Maths         Biology         Chemistry ");
        System.out.println("------------------------------------------");
        System.out.println(m + "            " + b + "              " + c);
        System.out.println("------------------------------------------");
        return total;
        //System.out.println("Total = "+ total);

    }
    // STUDENT METHOD END HERE  //

    // MAIN METHOD START HERE  //
    public static void main(String args[])
    {
        int total;

        System.out.println("\n******************************************************");
        System.out.println("STUDENT 1 DETAILS ");
        System.out.println("******************************************************");
        student1("Aasha", 13,1,50,50,50);


        System.out.println("\n******************************************************");
        System.out.println("STUDENT 2 DETAILS ");
        System.out.println("******************************************************");
        student2();


        System.out.println("\n******************************************************");
        System.out.println("STUDENT 3 DETAILS ");
        System.out.println("******************************************************");

        // FOR ACCESSING NON STATIC METHOD FROM STATIC METHOD NEED TO CREATE A CLASS  OBJECT //
        Student_record s = new Student_record();
        total= s.student3("Naina", 13,3,70,70,70);
        System.out.println("Total = " + total);

        System.out.println("\n******************************************************");
        System.out.println("STUDENT 4 DETAILS ");
        System.out.println("******************************************************");

        // FOR ACCESSING NON STATIC METHOD FROM STATIC METHOD NEED TO CREATE A CLASS  OBJECT  //
        total= s.student4();
        System.out.println("Total = " + total);


    }
    // MAIN METHOD END HERE  //



    // CLASS END HERE   //
}
