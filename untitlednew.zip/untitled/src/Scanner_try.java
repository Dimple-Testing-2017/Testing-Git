/**
 * Created by ATMIYA2020 on 24/06/2017.
 */
import java.util.Scanner;

public class Scanner_try {

 public static void main(String args[])
 {
     int a,b;
     String src;
     Scanner_try try = new Scanner_try();
     System.out.println("Enter roll number -->");
     a = try.nextInt();



 }
}
