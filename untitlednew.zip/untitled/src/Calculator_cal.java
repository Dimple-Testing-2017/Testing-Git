/**
 * Created by ATMIYA2020 on 20/06/2017.
 */
public class Calculator_cal {
    //***********    CALCULATOR CLASS START HERE    ********* //
    //  METHOD START FROM HERE      //

    //******     NO RETURN WITH PARAMETER   ****** //
    public static void addition(int a, int b) {
        int ans = a + b;
        System.out.println("*********   ADDITION OF TWO NUMBERS   ********");
        System.out.println("The Answer of a = " + a + " and b = " + b + " Addition is --> " + ans);
    }

    //********  NO RETURN WITHOUT PARAMETER  *******//
    public static void subtract() {
        int a = 30, b = 10;
        int ans = a - b;
        System.out.println("\n*********   SUBTRACTION OF TWO NUMBERS   ********");
        System.out.println("The Answer of a = " + a + " and b = " + b + " Substract is --> " + ans);
    }

    //********  RETURN WITH PARAMETER  *******//
    public int multiplication(int a, int b)
    {
        int ans;
        return ans = a * b;
        //System.out.println("The Answer of a = "+ a + " and b = " + b + " Multiplication is -->" + ans);
    }

    //********  RETURN WITHOUT PARAMETER  *******//
    public int division()
    {
        int a = 200, b = 10;
        int ans;
        ans = a / b;
        System.out.print("The Answer of a = " + a + " and b = " + b );
        return ans;
    }

    public static void main(String[] args) {
        //*******************      MAIN METHOD START HERE   ******************  //
        int answer, a=100, b=10;

        // CALLING METHODS FROM  HERE //
        addition(10, 10);
        subtract();

        // FOR RETURN TYPE WITH PARAMETER SO FROM STATIC METHOD TO CALLING NON STATIC METHOD NEED TO CREATE CLASS OBJECT //
        Calculator_cal c = new Calculator_cal();
        answer = c.multiplication(a,b);

        System.out.println("\n*********   MULTIPLICATION OF TWO NUMBERS   ********");
        System.out.println("The Answer of a = "+ a + " and b = " + b + " Multiplication is --> " + answer);

        // RETURN TYPE WITHOUT PARAMETERS //
        System.out.println("\n*********   DIVISION OF TWO NUMBERS   ********");
        answer=c.division();
        System.out.println(" Division is --> " + answer);
        //******************       MAIN METHOD END HERE   ****************** //
    }

}
