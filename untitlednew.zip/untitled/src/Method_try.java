/**
 * Created by ATMIYA2020 on 24/06/2017.
 */
public class Method_try {

    // METHOD DECLARATION //

    public int addition(int a, int b)
    {
        int c;
        c=a+b;
      //  System.out.println("Value of a"+ a + "value of b" + b + "Additon is --> "+ c );
        return c;
    }



    public static void main(String args[])
    {
        int a=20, b=20;
        Method_try  method_try = new Method_try();
        int c;
        c = method_try.addition(a,b);
        System.out.println("Value of a"+ a + "value of b" + b + "Additon is --> "+ c );

    }
}
