/*     16. Write a Java program to test if an array contains a specific value. */

import java.util.Scanner;
public class Program_16 {

    // MAIN METHOD START FROM HERE  //
    public static void main(String args[])
    {
        int i;
        int t,l;
        int s[] = new int[10];
        boolean bln=false;

        // SCANNER CLASS OBJECT IS CREATING HERE //
        Scanner scanner = new Scanner(System.in);

        // ASKING 10  ARRAY VALUE FROM USER  HERE //
        for (i = 0; i < 10; i++)
        {
            System.out.print("Please enter 10 Value of Array -->");
            t = scanner.nextInt();
            s[i] = t;
        }
        // ASKING VALUE FROM USER TO SEARCH IN ARRAY //
        System.out.print("\n\nPlease enter the value to check Array contains or not --> ");
        Scanner scn = new Scanner(System.in);
        l = scanner.nextInt();

        // SEARCHING VALUE FROM AN ARRAY //
        for (i = 0; i < 10 ; i++)
        {
            if(l==s[i])
            {
                System.out.println("\nAn Array contains your value!!" );
                System.out.println("An Array index of your value is --> " +"s["+ i +"]");
                bln=true;
            }
            //System.out.println("An Array value not Match the value enter by you ");
           // break;
        }
        if(bln==false) System.out.println("An Array not Match the value enter by you ");

    }
// MAIN METHOD END HERE //
    }

