/*    Write a Java program to find the index of an array element.     */

import java.util.Scanner;
public class Program_17 {

    public static void main(String args[]) {
        int i;
        int t, l;
        int s[] = new int[10];
        boolean bln = false;

        // SCANNER CLASS OBJECT IS CREATING HERE //
        Scanner scanner = new Scanner(System.in);

        // ASKING 10 VALUE FROM THE USER FOR AN ARRAY//
        System.out.print("Please enter 10 Value of Array -->");
        for (i = 0; i < 10; i++)
        {
            t = scanner.nextInt();
            s[i] = t;
        }

        // ASKING INDEX VALUR FOR AN ARRAY TO CHECK   //
        System.out.print("\n Please enter the Index value for an Array to check --> ");
        Scanner scn = new Scanner(System.in);
        l = scanner.nextInt();

        // PRINTING INDEX VALUE  //
        System.out.println("Value of the index is --> "+ s[l] );
    }
// MAIN METHOD END HERE  //
}

