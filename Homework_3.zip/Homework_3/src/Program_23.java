/*     23. Write a Java program to find the common elements between two arrays of integers.     */

import java.util.Scanner;
public class Program_23 {

    public static void main(String args[])
    {
        int s[] = new int [10];
        int s1[] = new int [10];
        int i,j,x;
        boolean b=false;

        // SCANNER CLASS OBJECT IS CREATING AND ASKIN 10 VALUE FOR ARRAY1   //
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter 10 Value of Array1 -->");
        for (i = 0; i < 10; i++) {
            x = scanner.nextInt();
            s[i] = x;
        }

        // ASKING 10 VALUE FOR ARRAY 2//
        System.out.print("Please enter 10 Value of Array2 -->");
        for (i = 0; i < 10; i++) {
            x = scanner.nextInt();
            s1[i] = x;
        }

        // CHECKING COMMON ELEMENT BETWEEN 2 ARRAYS   //
        System.out.println("***   Match values of Array1 and Array2  *** ");
        for(i=0; i<s.length; i++)
        {
            for(j=0; j<s1.length; j++)
            {
                if(s[i] == s1[j])
                {
                    System.out.println("Match value of Array1 and Array2 is --> "+ s[i]);
                    b=true;
                }
            }
        }

        if(b == false)
            System.out.println("There is no Match values find in an Array" );

    }
// MAIN METHOD END HERE  //
}
