/*  WAP to Enter and print the number of rows for floyd's triangle.
   For eg: Number of rows in Floyd's triangle : 6
   Floyd's triangle
    1
    2 3
    4 5 6
    7 8 9 10
    11 12 13 14 15
    16 17 18 19 20 21
 */

import java.util.Scanner;
public class Program_10 {

    // MAIN METHOD SSTART HERE //
    public static void main(String args[])
    {
        int a,t=1;

        // SCANNER CLASS OBJECT IS CREATING HERE  AND ASKING NUMBER OF ROW VALUE FROM USER//
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter any Digital value -->");
        a = scanner.nextInt();

     // PRINTING THE VALUE BY ROW AND COLUMN WISE HERE  //
        for (int i=1; i<=a; i++ )
        {
            for(int j=1;j<=i; j++)
            {
                System.out.print("  " + t);
                t++;
            }
            System.out.println("  ");
        }

    }
// MAIN METHOD END HERE //
}

