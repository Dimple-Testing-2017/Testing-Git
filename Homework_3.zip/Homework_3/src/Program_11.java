/*      Display left angle triangle of @ using nested for loops
*
* *
* * *
* * * *
* * * * *

 */

import java.util.Scanner;
public class Program_11 {

    //MAIN METHOD START HERE//
    public static void main(String args[])
    {
        //int a[][];
        int s,i,j;

        //ASKING USER TO ENTER THE NUMBER OF ROW VALUE//
        Scanner scanner= new Scanner(System.in);
        System.out.println("Please enter the number of Row -->");
        s = scanner.nextInt();

        // PRINTING THE VALUE BY ROW AND COLUMN WISE FROM HERE //
        for(i=1; i<=s; i++)
        {
            for(j=s; j>0; j--)
            {
                if(i < j)
                    System.out.print(" ");
                else
                    System.out.print("*");
            }
            System.out.print("\n");
        }
    }
    //MAIN METHOD END HERE  //

}
