/*  Write a program in Java to display the pattern like triangle with a number.
For eg.
Input number of rows : 10
Expected Output :
1
12
123
1234
12345
123456
1234567
12345678
123456789
12345678910
 */
// ******************************************        PROGRAMME START FROM HERE    *************************************** //

import java.util.Scanner;
import java.awt.Dimension;
public class Programe_3 {

    //MAIN METHOD START FROM HERE  //
        public static void main(String args[])
        {
          //ARRAY DECLARATION HERE BY 10 ROW AND 10 COLUMN//
                int a[][];
                int b,i,j,t=0;

         //SCANNER CLASS OBJECT CREATING AND ASKING VALUE FROM USER    //
                Scanner scanner = new Scanner(System.in);
                System.out.println("Please enter the Number of Row to print -->");
                b = scanner.nextInt();

         // i FOR NUMBER OF ROW  AND j FOR NUMBER OF COLUMN    //
                for ( i = 0; i < b; i++)
                {
                    for ( j = b; j > i; j--)
                    {
                        System.out.print(" ");
                    }
                    for (int k = 1; k <= i + 1; k++) {
                        System.out.print(" " + k);
                    }
                    System.out.print("\n");
                }
        }
//MAIN METHOD END HERE //

        }

