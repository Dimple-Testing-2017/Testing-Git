/* WAP to input any number and heck if it Prime number or not */

import java.util.Scanner;
public class Program_8 {

//*******************************    THIS PROGRAM IS NOT WORKING  NOT DONE YET  **********************////
// MAIN METHOD SSTART HERE //
    public static void main(String args[])
    {
      int a;

      // SCANNER CLASS OBJECT IS CREATING HERE //
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter any Digital value -->");
        a = scanner.nextInt();


        for (int i=1; i<=a; i++ )
        {
            if( i % 2 !=0 || i % i !=0 )
            {
                System.out.print("  " + i);
            }

        }

    }
// MAIN METHOD END HERE //
}
