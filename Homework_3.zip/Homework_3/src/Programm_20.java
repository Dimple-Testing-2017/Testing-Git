
/*  20. Write a Java program to find the maximum and minimum value of an array.  */

import java.util.Scanner;
public class Programm_20 {

    //MAIN METHOD START FROM HERE //
    public static void main(String args[])
    {
        int i;
        int t, max=0,min;
        int s[] = new int[10];

        // SCANNER CLASS OBJECT IS CREATING AND INSERT THE 10 VALUE FROM USER //
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter 10 Value of Array -->");
        for (i = 0; i < 10; i++)
        {
            t = scanner.nextInt();
            s[i] = t;
        }

       // FOR CHECKING MAXIMUM VALUE //
        for (i = 0; i < 10; i++)
        {
            if(max <= s[i])
             {
                max = s[i];
             }
        }
        System.out.println("Maximum Value of an Array is -->"+ max);

        // FOR CHECKING MINIMUM VALUE  //
        min=s[0];
        for (i = 0; i < 10; i++)
        {
            if( s[i] <= min )
            {
                min = s[i];
            }
        }
        System.out.println("Minimum Value of an Array is -->"+ min);
    }
 // MAIN METHOD END HERE  //
}
