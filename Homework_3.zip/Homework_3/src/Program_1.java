/*  WAP to print the numbers between 1 to 100 which can be divided by 3 and 5 separately */

public class Program_1
{

    // MAIN METHOD START HERE  //
    public static void main(String args[])
    {

        // VARIABLE DECLARATION START HERE  //
        int i=1;

        // HEADING IS PRINT HERE  //
        System.out.println("Numbers Devided by 3 is -->");

        // FOR LOOP FOR NUMBERS DIVIDED BY 3   //
        for(i=1; i<=100;i++)
        {
            if(i%3==0)
            {
                System.out.print("  " + i);
            }
        }

        // HEADING IS PRINT HERE FOR NUMBERS DIVIDE BY 5 //
        System.out.println("\n \n Numbers Devided by 5 is -->");

        // FOR LOOP FOR NUMBERS DIVIDED BY 5   //
        for(i=1; i<=100;i++)
        {
            if (i % 5 == 0) {
                System.out.print("  " + i);
            }

        }
    }
    // MAIN METHOD END HERE  //

}
