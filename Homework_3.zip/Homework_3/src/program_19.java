/*   19. Write a Java program to insert an element (specific position) into an array.   */

import java.util.Scanner;
public class program_19 {

    // MAIN METHOD START HERE  //
    public static void main(String args[])
    {
        int i;
        int t, l,in_val;
        int s[] = new int[10];

        // SCANNER CLASS OBJECT IS CREATING AND ASKING 10 VALUE FROM THE USER //
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter 10 Value of Array -->");
        for (i = 0; i < 10; i++)
        {
            t = scanner.nextInt();
            s[i] = t;
        }

        // ASKING INDEX NUMBER AND VALUE TO INSERT IT //
        System.out.print("Please enter the Index number to insert the value --> ");
        l = scanner.nextInt();

        System.out.print("Please enter the value to insert it--> ");
        in_val = scanner.nextInt();

        s[l] = in_val;

        // PRINTING THE FINAL RESULT AFTER INSERT THE VALUE //
        System.out.println("After insert the value from an Array Reault is -->");
        for(i = 0; i < 10; i++)
        {
            System.out.println("Final Result is -->" + s[i]);
        }

    }
// MAIN METHOD END HERE //
}
