/*      Write a Java program to find the duplicate values of an array of integer values.  */

import java.util.Scanner;
public class Programme_21 {

    // MAIN METHOD START FROM HERE  //
    public static void main(String args[])
    {
        int s[] = new int[10];
        int i, j,t,dup =0;
        boolean b=false;

        // SCANNER CLASS OBJECT CREATING AND ASKING 10 ARRAY VALUE   //
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter 10 Value of Array -->");
        for (i = 0; i < 10; i++) {
            t = scanner.nextInt();
            s[i] = t;
        }

       // System.out.println("*****  To find Duplicate values of an Array is ******  ");

        // CHECKING DUPLICATE VALUE BY COMPARING EACH ELEMENT TO EACH OTHER   //
        for(i=0; i<s.length; i++)
        {
            for(j= i + 1; j<s.length; j++)
            {
                if(s[i] == s[j])
                {
                    System.out.println("There is duplicate value in an Array is --> "+ s[i] );
                    b=true;
                }
            }
        }
        if(b == false)
        System.out.println("There is no duplicate value in an Array" );
    }
// MAIN METHOD END HERE //
}
