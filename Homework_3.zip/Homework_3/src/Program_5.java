/*   Print the sequence 1 1 2 3 5 8 13 21 (Fibonacci number) */

import java.util.Scanner;

public class Program_5 {

    // MAIN METHOD START HERE  //
    public static void main(String args[])
    {
        int sum=0, no1=0,no2=1,a;

        // SCANNER CLASS OBJECT CREATING AND ASKING VALUE FROM USER //
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter the Number of Row to print -->");
        a= scanner.nextInt();

        System.out.println(" Fibonacci ceries up to the User value is -->");
        for(int i=1; i<= a; i++)
        {
            System.out.print("  " + no2 );
            sum= no1 + no2;
            no1 = no2;
            no2 = sum;
        }
    }
    //MAIN METHOD END HERE   //
}
