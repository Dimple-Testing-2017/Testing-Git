/*    12. Write a Java program to sort a numeric array and a string array.     */

import java.util.Arrays;
import java.util.Scanner;
public class Program_12 {

// MAIN METHOD START FROM HERE   //
    public static void main(String args[]) {

        String str[] = new String[10];
        String s_val,str_sort;
        int s[] = new int[10];
        int i, t,j,temp,len=0, sel_opt=0;
        int x= 0;

        //SCANNER CLASS OBJECT IS CREATING AND ASKING THE USER CHOICE FOR SORTING NUMERICAL AND STRING VALUE //
        Scanner scanner = new Scanner(System.in);
        System.out.println(" Please select 1 for Integer array sort \t\t 2 for string array sort ");
        sel_opt=scanner.nextInt();

        // SWITCH LOOP FOR ASKING USER CHOICE //
     switch (sel_opt) {
         case 1:        // FOR INTEGER ARRAY SORT HERE//
                         System.out.println("For Integer Array sort, Please Press 1");
                         System.out.println("Please enter 10 Value of Array -->\n ");

                         //ASKING VALUE FROM USER //
                         for (i = 0; i < 10; i++) {
                             t = scanner.nextInt();
                             s[i] = t;
                         }
                         System.out.println("*****   Sorting the Numeric Array  ******  ");
                         //   SORTING INTEGER VALUE    //
                         for (i = 0; i < s.length; i++) {
                             for (j = i + 1; j < s.length; j++) {
                                 if (s[i] > s[j]) {
                                     temp = s[i];
                                     s[i] = s[j];
                                     s[j] = temp;
                                 }
                             }
                             System.out.println(" " + s[i]);
                         }
             break;

         case 2:     // FOR STRING ARRAY SORT HERE  //
                    // ASKING 10 STRING ARRAY VALUE FROM USER//
                     System.out.print("Please enter 10 strings of Array --> \n");
                     for (i = 0; i < 10; i++) {
                         s_val = scanner.next();
                         str[i] = s_val;
                     }
                     System.out.println("*****   Sorting the  String Array  ******  ");
                     // ARRAY PACKAGE HHAVE READY SORT METHOD FOR SORT THE ARRAY SO WE USED IT //
                     Arrays.sort(str);
                     // PRINTING SORTED ARRAY RESULT //
                     for (i = 0; i < s.length; i++) {
                         System.out.println(" " + str[i]);
                     }
             break;
         default:
             System.out.println("  Please enter the valid number from 1 or 2;");
             break;
     }
    }
    // MAIN METHOD END HERE //
}
