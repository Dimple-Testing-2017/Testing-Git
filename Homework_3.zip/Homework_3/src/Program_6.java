/*
WAP to input any number and check if it is Armstrong number or not
 */

import java.util.Scanner;
public class Program_6 {

    //  MAIN METHOD START HERE //
    public static void main(String args[]) {

        int a,temp,sum=0,store=0;

        // SCANNER CLASS OBJECT CREATING AND ASKING VALUE FROM USER //
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter any Number for checking it is Armstrong or not  -->");
        a= scanner.nextInt();

        // STORING THE USER VALUE TO TEMPORARY VARIABLE //
        store = a;

        //DEVIDING THE NUMBER HERE DOING MULTIPLICATION AND SUM OF THE NUMBERS //
         while(a>0)
            {
                temp = a % 10;
                a= a/10;
                sum = sum + (temp*temp*temp);
            }

            // CHECKING SUM OF NUMBERS IS EQUAL TO USER ENTERED VALUE //
            if( store == sum)
            {
                System.out.println("It's armstrong number --> "+ store );
            }
            else
            {
                System.out.println("Not a armstrong number --> "+ store);
            }
    }
  // MAIN METHOD END HERE  //
}