/*     Write a Java program to reverse an array of integer values.     */

import java.util.Scanner;
public class Program_21 {

    // MAIN METHOD START HERE  //
    public static void main(String args[])
    {
        int s[] = new int[10];
        int i,t;

        // SCANNER CLASS OBJECT CREATING AND ASKING 10 VALUE FROM USER //
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter 10 Value of Array -->");
        for (i = 0; i < 10; i++)
        {
            t = scanner.nextInt();
            s[i] = t;
        }

        // REVERSE THE VALUE OF AN ARRAY FROM HERE    //
        System.out.println("*****   Reverse value of an Array is ******  ");
        for (i = 9; i >= 0; i--)
        {
             System.out.println("Reverse value is --> " + s[i]);
        }

    }
    //MAIN METHOD END HERE  //
}
