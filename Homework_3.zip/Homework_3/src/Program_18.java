/*     18. Write a Java program to remove a specific element from an array.     */

import java.util.Scanner;
public class Program_18 {
 // MAIN METHOD START HERE //
    public static void main(String args[])
    {
        int i;
        int t, l;
        int s[] = new int[10];

        // CREATING SCANNER CLASS OBJECT AND ASKING 10 VALUE FOR AN ARRAY FROM USER //
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter 10 Value of Array -->");
        for (i = 0; i < 10; i++)
        {
            t = scanner.nextInt();
            s[i] = t;
        }

        // ASKING INDEX  TO REMOVE THE VALUE FROM AN ARRAY   //
        System.out.print("Please enter the Index value to remove from an Array --> ");
        l = scanner.nextInt();

        s[l] = 0;

        // PRINTING THE VALUE AFTER REMOVE THE VALUE//
        System.out.println("After remove the value from an Array Reault is -->");
        for(i = 0; i < 10; i++)
        {
            System.out.println("Final Reault is -->" + s[i]);
        }

    }
// MAIN METHOD END HERE //
}
