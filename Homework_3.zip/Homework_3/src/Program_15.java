/*    15.  Write a Java program to calculate the average value of array elements.
                      COMBINING PROGRAMME
      13. Write a Java program to sum values of an array.
*/

import java.util.Scanner;
public class Program_15 {

    // MAIN METHOD START FROM HERE //
    public static void main(String args[])
    {
        int i;
        Double t , sum=0.0,avg=0.0;
        Double s[] = new Double[10];

        // SCANNER CLASS OBJECT CREATING//
        Scanner scanner = new Scanner(System.in);

        //    ASKING 10 ARRAY VALUE FROM USER BY USING SCANNER CLASS  AND DOING SUM AND AVERAGE//
        for (i = 0; i < 10; i++)
        {
            System.out.print("Please enter 10 Value of Array -->");
            t = scanner.nextDouble();
            s[i] = t;
            sum= sum+ s[i];  // PROGRAMME 13 FINISH HERE //
            avg= sum/.0;     // PROGRAMME 15 FINISH HERE //
        }
        System.out.println("Sum is --> " + sum);
        System.out.println("Average  is --> " + avg);
    }
  // MAIN METHOD END HERE   //
}