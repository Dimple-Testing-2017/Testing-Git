/*        WAP to input any number and check if it is Palindrome or not      */

import java.util.Scanner;
public class Program_7
{
    // MAIN METHOD START FROM HERE //
    public static void main(String[] args) {

        int temp,store,a,rev=0;

        // SCANNER CLASS OBJECT CREATING AND ASKING VALUE FROM USER //
            Scanner scanner = new Scanner(System.in);
            System.out.println("Please enter any Number for checking it is pelindrome or not  -->");
            a = scanner.nextInt();

        // STORE USER VALUE TO A TEMPORARY VARIABLE  //
        store = a;

        // REVERSING THE VARIABLLE VALUE //
        while(a>0)
        {
            temp = a % 10;
            a= a/10;
            rev = rev *10 + temp;
            //System.out.println(" a is ->" + a);
        }

        // CHECKING REVERSE VALUE IS EQUAL TO THE USER VALUE //
        if(store == rev) {
            System.out.println("It's palindrome number -->" + store);
        } else {
            System.out.println("Not a palindrome number -->" + store);
        }

    }
    // MAIN METHOD END HERE //
}