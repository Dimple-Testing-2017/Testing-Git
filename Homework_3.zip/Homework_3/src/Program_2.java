/*  Write a program in Java to display n limit of natural numbers and their sum.
For eg. Input number: 7
Expected Output :
The first n natural numbers are : 7
1
2
3
4
5
6
7
The Sum of Natural Number upto n limit : 28
*/
import java.util.Scanner;
public class Program_2
{
   //MAIN METHOD START HERE //
        public static void main(String args[])
        {
            int a,total=0;
            // SCANNEER CLASS OBJECT CREATING HERE //
                    Scanner scanner = new Scanner(System.in);
                    System.out.println("Please enter any Digital number --> ");
                    a = scanner.nextInt();

            // PRINTING HEADING OF NUMBERS //
                    System.out.println("Natural numbers up to the digital value enter by User is ---> ");

            // FOR LOOP FOR DOING TOTAL AND PRINTING DIGITAL NUMBERS AS WELL//
                    for(int i=1; i<= a; i++)
                    {
                        System.out.print("  " + i);
                        total = total + i;
                        //FOR NEXT LINE PRINTING RESULT //
                        if(i==50)
                        {
                            System.out.print("\n");
                        }
                    }
                    System.out.println("\n\nThe Total of Natural numbers is --> " + total);
        }
    // MAIN METHOD END HERE  //

}