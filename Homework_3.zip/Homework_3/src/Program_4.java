/*
Display right angle triangle of @ using nested for loops
@
@@
@@@
@@@@
@@@@@
 */

import java.util.Scanner;
public class Program_4 {

    //MAIN METHOD START HERE//
    public static void main(String args[])
    {
        int a[][];
        int s,i,j;

        //ASKIN USER ENTER THE NUMBER OF ROW VALUE//
        Scanner scanner= new Scanner(System.in);
        System.out.println("Please enter the number of Row -->");
        s = scanner.nextInt();

        // FOR LOOP FOR PRINTING THE RESULT //
        for(i=1; i<=s; i++)
        {
            for(j=1; j<=i; j++)
            {
                System.out.print(" @ ");
            }
            System.out.print("\n");
        }
    }
    //MAIN METHOD END HERE  //

}
