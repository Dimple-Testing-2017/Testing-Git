/*   Write a Java program to find the second largest element in an array.   */

import java.util.Scanner;
public class Program_25 {

    // MAIN METHOD START HERE //
    public static void main(String args[])
    {
        int s[] = new int[10];
        int i, j,t;
        int large_value,second_large;

        // SCANNER CLASS OBJECT CREATING AND INSERT THE 10 VALUE //
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter 10 Value of Array -->");
        for (i = 0; i < 10; i++) {
            t = scanner.nextInt();
            s[i] = t;
        }
        // FOR CHECKING MAXIMUM VALUE //

            if(s[0] <= s[1])
            {
                large_value = s[1];
                second_large = s[0];
            }
            else
            {
                large_value = s[0];
                second_large = s[1];
            }
        for (i = 2; i < 10; i++)
        {
            if((s[i]<= large_value) && (s[i]>=second_large))
            {
                second_large=s[i];
            }
            if(s[i]> large_value)
            {
                second_large = large_value;
                large_value = s[i];
            }
        }
        //System.out.println("Maximum Value of an Array is -->"+ large_value);
        System.out.println("Second large Value of an Array is -->"+ second_large);
    }
    // MAIN METHOD END HERE //
}
