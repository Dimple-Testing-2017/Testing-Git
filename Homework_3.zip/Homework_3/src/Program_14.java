/* Write a Java program to print the following grid.
Expected Output :
- - - - - - - - - -
- - - - - - - - - -
- - - - - - - - - -
- - - - - - - - - -
- - - - - - - - - -
- - - - - - - - - -
- - - - - - - - - -
- - - - - - - - - -
- - - - - - - - - -
- - - - - - - - - -
 */

import java.util.Scanner;
public class Program_14 {

    //MAIN METHOD START HERE//
    public static void main(String args[])
    {
        int t;

        // SCANNER CLASS OBJECT IS CREATING HERE //
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter any Digital value -->");
        t = scanner.nextInt();

        // PRINTING THE DASH ACCORDING TO USER VALUE ENTER //
        for(int i=1; i<=t; i++)
        {
            for(int j = 1; j <=t; j++)
            {
                System.out.print(" -");
            }
            System.out.println(" ");
        }
    }
    // MAIN METHOD END HERE //
}