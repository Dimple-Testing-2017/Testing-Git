import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.concurrent.TimeUnit;

/**
 * Created by ATMIYA2020 on 12/07/2017.
 */
public class Facebook_page {

    public static void main(String args[]) {
        WebDriver fb_driver = new FirefoxDriver();
        fb_driver.manage().window().maximize();
        fb_driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);

        fb_driver.get("https://en-gb.facebook.com/");

        fb_driver.findElement(By.xpath(".//*[@id='u_0_2']")).sendKeys("Krishnaraj");
        fb_driver.findElement(By.xpath(".//*[@id='u_0_4']")).sendKeys("Patel");

        fb_driver.findElement(By.xpath(".//*[@id='u_0_7']")).sendKeys("07722234152");
        fb_driver.findElement(By.xpath(".//*[@id='u_0_e']")).sendKeys("holiday123");

      // Birthday select  //
        Select fb_day = new Select(fb_driver.findElement(By.xpath(".//*[@id='day']")));
        fb_day.selectByIndex(5);

        Select fb_month = new Select(fb_driver.findElement(By.xpath(".//*[@id='month']")));
        fb_month.selectByVisibleText("Aug");

        Select fb_year = new Select(fb_driver.findElement(By.xpath(".//*[@id='year']")));
        fb_year.selectByVisibleText("2000");

        //CHECKBOX SELECT  //
        fb_driver.findElement(By.xpath(".//*[@id='u_0_h']")).click();
        //FOR BUTTON  //
        fb_driver.findElement(By.xpath(".//*[@id='u_0_m']")).click();


    }
}
