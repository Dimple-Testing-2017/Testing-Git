import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.concurrent.TimeUnit;

import static org.testng.Assert.assertNotNull;

/**
 * Created by ATMIYA2020 on 12/07/2017.
 */
public class Sky_page {

    public static void main(String args[])
    {
        WebDriver sky_driver = new FirefoxDriver();
        sky_driver.manage().window().maximize();
        sky_driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);

        sky_driver.get("https://www.sky.com/");

        // IT WILL CLICK ON SIGN IN IN HOMEPAGE AND THEN SIGN UP ON SECOND PAGE THE ON REGISTRATION PAGE //
        sky_driver.findElement(By.linkText("Sign In")).click();
        sky_driver.findElement(By.linkText("Sign up")).click();

        // IT IS STARTING TO FILL FORM   //
        Select sky_obj = new Select(sky_driver.findElement(By.xpath(".//*[@id='title']")));
        sky_obj.selectByVisibleText("Mrs");

        sky_driver.findElement(By.xpath(".//*[@id='firstname']")).sendKeys("Divya");
        sky_driver.findElement(By.xpath(".//*[@id='lastname']")).sendKeys("Patel");

        sky_driver.findElement(By.xpath(".//*[@id='email']")).sendKeys("Holiday2010@yahoo.com");
        sky_driver.findElement(By.xpath(".//*[@id='confirmEmail']")).sendKeys("Holiday2010@yahoo.com");
        sky_driver.findElement(By.xpath(".//*[@id='password']")).sendKeys("havefun123");
        sky_driver.findElement(By.xpath(".//*[@id='confirmPassword']")).sendKeys("havefun123");
        sky_driver.findElement(By.xpath(".//*[@id='captcha']")).sendKeys("mbmxh");

        //ASSERT NOT NULL CHECKING HERE //
        String textget=  sky_driver.findElement(By.xpath(".//*[@id='captcha']")).getText();
        assertNotNull("Please enter the value in Text box of captcha ",textget);

        // FOR CHECKBOX CLICK //
        sky_driver.findElement(By.xpath(".//*[@id='termsAndConditions']")).click();
        sky_driver.findElement(By.xpath(".//*[@id='marketingOptOut']")).click();

        // FOR BUTTON CLICK //
        sky_driver.findElement(By.xpath(".//*[@id='submitButton']")).click();



    }

}
