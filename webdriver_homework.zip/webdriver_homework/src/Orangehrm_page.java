import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.concurrent.TimeUnit;

/**
 * Created by ATMIYA2020 on 12/07/2017.
 */
public class Orangehrm_page {

    public static void main(String args[])
    {
        WebDriver ohrm = new FirefoxDriver();
        ohrm.manage().window().maximize();
        ohrm.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);


        ohrm.get("http://opensource.demo.orangehrmlive.com/");

        // FOR USERNAME AND PASSWORD ENTRY START HERE FOR HOME PAGE //
        ohrm.findElement(By.xpath(".//*[@id='txtUsername']")).sendKeys("Admin");
        ohrm.findElement(By.xpath(".//*[@id='txtPassword']")).sendKeys("admin");
        ohrm.findElement(By.xpath(".//*[@id='btnLogin']")).click();

        // FOR CLICK PIM MENU //

        ohrm.findElement(By.xpath(".//a[@id='menu_pim_viewPimModule']")).click();
        ohrm.findElement(By.xpath(".//a[@id='menu_pim_addEmployee']")).click();

        //ADD EMPLOYEE DETAILS START FROM HERE //

        ohrm.findElement(By.xpath(".//*[@id='firstName']")).sendKeys("Ananya1111q611");
        ohrm.findElement(By.xpath(".//*[@id='middleName']")).sendKeys("Parmesh1");
        ohrm.findElement(By.xpath(".//*[@id='lastName']")).sendKeys("Patel1");
        ohrm.findElement(By.xpath(".//*[@id='employeeId']")).sendKeys("");

        // NO NEED TO BROWSE PHOTOS HERE //
        ohrm.findElement(By.xpath(".//*[@id='chkLogin']")).click();

        //USERNAME AND PASSWORD CREATING //
        ohrm.findElement(By.xpath(".//*[@id='user_name']")).sendKeys("Holiday_enjoy116q111");
        ohrm.findElement(By.xpath(".//*[@id='user_password']")).sendKeys("holiday555*");
        ohrm.findElement(By.xpath(".//*[@id='re_password']")).sendKeys("holiday555*");

        // NEED SELECT OBJECT FOR SELECTING THE STATUS//
        Select status_obj = new Select(ohrm.findElement(By.xpath(".//*[@id='status']")));
        status_obj.selectByVisibleText("Disabled");

        //SAVE BUTTON//
        ohrm.findElement(By.xpath(".//*[@id='btnSave']")).click();

        //REMAINING FIELDS NEED TO FILL ON OTHER PAGE //
        ohrm.findElement(By.xpath(".//*[@id='btnSave']")).click();
        ohrm.findElement(By.xpath(".//*[@id='personal_txtLicenNo']")).sendKeys("B78s8291");
        ohrm.findElement(By.xpath(".//*[@id='personal_optGender_2']")).click();
        Select nationality = new Select(ohrm.findElement(By.xpath(".//*[@id='personal_cmbNation']")));
        nationality.selectByVisibleText("Indian");
        ohrm.findElement(By.xpath(".//*[@id='personal_txtOtherID']")).sendKeys("Emp30921");

        //LICENCE EXPIRY DATE SELECT// //need to sort out this  //
        Select licence = new Select(ohrm.findElement(By.xpath(".//*[@id='personal_txtLicExpDate']")));
        licence.selectByVisibleText("2017-04-10");

        // MARITUAL STATUS //
        Select maritual = new Select(ohrm.findElement(By.xpath(".//*[@id='personal_cmbMarital']")));
        nationality.selectByVisibleText("Married");

        //DATE OF BIRTH DATE SELECT// //need to sort out this  //
        Select dob = new Select(ohrm.findElement(By.xpath(".//*[@id='personal_txtLicExpDate']")));
        dob.selectByVisibleText("2017-04-10");

        ohrm.findElement(By.xpath(".//*[@id='btnSave']")).click();


    }
}
