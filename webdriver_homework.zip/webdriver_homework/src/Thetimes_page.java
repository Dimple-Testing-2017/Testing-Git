
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.concurrent.TimeUnit;

/**
 * Created by ATMIYA2020 on 11/07/2017.
 */
public class Thetimes_page {

    public static void main(String args[]) {

        WebDriver times_driver = new FirefoxDriver();
        times_driver.manage().window().maximize();
        times_driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);


        times_driver.manage().deleteAllCookies();

        times_driver.get("https://join.thetimes.co.uk");
        times_driver.findElement(By.xpath("//div[@id=\"a3J200000004RKBEA2\"]/div/div/button")).click();
        times_driver.get("https://join.thetimes.co.uk");

        // FOR TITTLE SELECTING WITH SELECT //
        // Select select_obj = new Select(times_driver.findElement(By.id("title")));
        Select select_obj = new Select(times_driver.findElement(By.xpath("//*[@id='title']")));
        select_obj.selectByVisibleText("Mrs");

         times_driver.findElement(By.xpath("//*[@id='firstName']")).sendKeys("Ananya");
         times_driver.findElement(By.xpath("//*[@id='lastName']")).sendKeys("Patel");
         times_driver.findElement(By.xpath("//*[@id='email']")).sendKeys("holiday2000@gmail.com");
         times_driver.findElement(By.xpath("//*[@id='confirmEmail']")).sendKeys("holiday2000@gmail.com");
         times_driver.findElement(By.xpath("//*[@id='password']")).sendKeys("fun2000enjoy");
         times_driver.findElement(By.xpath("//*[@id='confirmPassword']")).sendKeys("fun2000enjoy");

         //BY INDEX working here PERFECT //
        Select dob = new Select(times_driver.findElement(By.xpath("//*[@id='dateOfBirthDay']")));
        dob.selectByIndex(15);

        //BY INDEX NOT WORKING SO I TOOK BY VISIBLE TEXT HERE //
        Select month = new Select(times_driver.findElement(By.xpath("//*[@id='dateOfBirthMonth']")));
        month.selectByVisibleText("May");

        // I TOOK BY VISIBLE TEXT HERE \AS WELL VALUE WORKING GOOD//
        Select year = new Select(times_driver.findElement(By.xpath("//*[@id='dateOfBirthYear']")));
        year.selectByValue("1995");

        times_driver.findElement(By.xpath("//*[@id='phone']")).sendKeys("07898876534");

        // FOR BUTTON //

        times_driver.findElement(By.xpath("//*[@id='accountCreationButton']")).click();

    // AFTER REGISTRATION PAGE 1 PAGE2 HAVE CARD DETAILS SO I DID STOP TO PROCESS //
    }
}

