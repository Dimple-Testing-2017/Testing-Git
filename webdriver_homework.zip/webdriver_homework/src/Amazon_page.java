import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

import java.util.concurrent.TimeUnit;

/**
 * Created by ATMIYA2020 on 09/07/2017.
 */
public class Amazon_page {

    public static void main(String args[]) {
        // FOR AMAZONE PAGE CREATING WEB DRIVER OBJECT  //

        String actual,expected;

        WebDriver driver_amazon = new FirefoxDriver();
        driver_amazon.manage().window().maximize();
        driver_amazon.manage().timeouts().implicitlyWait(7,TimeUnit.SECONDS );

        // IN AMAZONE HOME PAGE CLICK START HERE //
            driver_amazon.get("https://www.amazon.co.uk/dp/B01DFKBL68/ref=gw_aucc_bisc_newgrey?pf_rd_p=e18198bc-8455-41ef-8852-f39cb5f5da62&pf_rd_r=C1H1QNWY6ZEZ9ZZF57Z6");
            driver_amazon.findElement(By.linkText("Start here.")).click();


       //REGISTRATION START HERE //
        driver_amazon.findElement(By.name("customerName")).sendKeys("Ganesh");
        driver_amazon.findElement(By.name("email")).sendKeys("holiday.webit@gmail.com");
        driver_amazon.findElement(By.name("password")).sendKeys("password");
        driver_amazon.findElement(By.name("passwordCheck")).sendKeys("password");

        // BY ASSERT EQUALS WE CAN CHECK THE PASSWORD IS EQUAL OR NOT. IF RIGHT THEN DISPLAY MESSAGE BUT IF IT IS WRONG THEN ?????//

        driver_amazon.findElement(By.id("continue")).click();

// METHOD 1 FOR ASSERTEQUALS//
 /*       actual = driver_amazon.findElement(By.name("password")).getText();
        expected = driver_amazon.findElement(By.name("passwordCheck")).getText();

         Assert.assertEquals(actual,expected);
        //System.out.println("Your Test case is pass");
*/

// METHOD 2 FRO DISPLAY MESSAGE IF FAILS IN ASSERTEQUALS//


             actual = driver_amazon.findElement(By.name("password")).getText();
             expected = driver_amazon.findElement(By.name("passwordCheck")).getText();
             System.out.println(actual+"actaul \n");
             System.out.println(expected+ "expected \n");


            // actual="Jay";
             //expected="Jay1";

             Assert.assertEquals(actual,expected);
             System.out.println("Your Test case is pass int TRY block");


  // METHOD3 FOR USING .EQUALS() METHOD//
    /*    if(actual.equals(expected)) {
            System.out.println("Your Test case is pass");
        }
         else
             {
                 System.out.println("Your Test case is fail");
             }
*/


        //IT WILL CLOSE PARENT WINDOW AS WELL ALL REMAINING POP UP WINDOWS//
       // driver_amazon.close();
    }
}
