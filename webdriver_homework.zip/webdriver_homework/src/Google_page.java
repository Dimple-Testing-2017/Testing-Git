//import org.openqa.jetty.html.Select;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.lang.ref.SoftReference;
import java.util.concurrent.TimeUnit;


/**
 * Created by ATMIYA2020 on 09/07/2017.
 */
public class Google_page {

    public static void main(String args[])
    {
            String month;
            //      CREATING WEBDRIVER OBJECT  //
            WebDriver google_drive = new FirefoxDriver();

            //MAXIMIZE WINDOW AT OPENING PAGE //
            google_drive.manage().window().maximize();
            google_drive.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

              //OPENING PAGE URL //
            google_drive.get("https://www.google.com/gmail/about/");
            google_drive.findElement(By.linkText("CREATE AN ACCOUNT"));
            google_drive.get("https://accounts.google.com/SignUp?service=mail&continue=http%3A%2F%2Fmail.google.com%2Fmail%2F%3Fpc%3Dcarousel-about-en");

            // GETTING X-PATH OF ALL WEB ELEMENTS //
            google_drive.findElement(By.xpath("//*[@id='FirstName']")).sendKeys("Dimple");
            google_drive.findElement(By.xpath("//*[@id='LastName']")).sendKeys("Patel");
            google_drive.findElement(By.xpath("//*[@id='GmailAddress']")).sendKeys("holiday.2pal@gmail.com");
            google_drive.findElement(By.xpath("//*[@id='Passwd']")).sendKeys("holiday123*");
            google_drive.findElement(By.xpath("//*[@id='PasswdAgain']")).sendKeys("holiday123*");
            google_drive.findElements(By.id("BirthMonth"));
            google_drive.findElement(By.xpath(".//*[@id='BirthMonth']/div[1]")).sendKeys("May");
            //below code is working//
            google_drive.findElement(By.xpath("//input[@id='BirthDay']")).sendKeys("15");
            google_drive.findElement(By.xpath("//input[@id='BirthYear']")).sendKeys("2000");
            google_drive.findElement(By.xpath(".//*[@id='Gender']/div[1]")).sendKeys("Female");
            google_drive.findElement(By.xpath("//input[@id='RecoveryPhoneNumber']")).sendKeys("7722576154");
            google_drive.findElement(By.xpath("//input[@id='RecoveryEmailAddress']")).sendKeys("holiday2010@gmail1.com");
            google_drive.findElement(By.xpath(".//*[@id='CountryCode']/div[1]")).sendKeys("Honduras");
            google_drive.findElement(By.xpath("//input[@id='submitbutton']")).click();

    }

}
