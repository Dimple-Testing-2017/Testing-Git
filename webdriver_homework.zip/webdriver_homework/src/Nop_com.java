import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.util.Queue;
import java.util.concurrent.TimeUnit;

/**
 * Created by ATMIYA2020 on 12/07/2017.
 */
public class Nop_com {

    public static void main(String args[]){

        WebDriver nop_com =  new FirefoxDriver();
        nop_com.manage().window().maximize();
        nop_com.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);


        // CURSOR WILL CLICK ON REGISTER TEXT   //
        nop_com.get("https://www.nopcommerce.com/");
        nop_com.findElement(By.linkText("Register")).click();

        // WE ARE ON REGISTER PAGE NOW AND FILLING FORM //
        nop_com.findElement(By.xpath("//*[@id='ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_txtFirstName']")).sendKeys("Dimple");
        nop_com.findElement(By.xpath("//*[@id='ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_txtLastName']")).sendKeys("Patel");
        nop_com.findElement(By.xpath("//*[@id='ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_Email']")).sendKeys("holiday200@gmail.com");
        nop_com.findElement(By.xpath("//*[@id='ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_UserName']")).sendKeys("holiday_enjoy");

        //SELECT FOR SELECTING A COUNTRY FROM THE LIST //
        Select country_obj = new Select(nop_com.findElement(By.xpath("//*[@id='ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_ddlCountry']")));
        country_obj.selectByVisibleText("United Kingdom");

        // BELOW CODE IS WORKING NOW //
       /* WebElement list = nop_com.findElement(By.id("ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_ddlCountry")); // this will return web element
        list.click(); // this will open the dropdown list.
        list.sendKeys("American Samoa");  */

        // SELECT FOR YOUR ROLE//
        Select role = new Select(nop_com.findElement(By.xpath("//*[@id='ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_ddlRole']")));
        role.selectByVisibleText("Technical / developer");

        //list.("Business / sales / marketing");
               // list.typeText("14w"); // this will select option "14w".





        /*     CHECKBOX FOR OPTIONS
              HERE WE ARE CLICKING CHECK BOX SO CLICK EVENT IS COMING HERE          */
           nop_com.findElement(By.xpath("//*[@id='ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_cbNewsletter']")).click();

        // FOR PASSWORD //
         nop_com.findElement(By.xpath("//*[@id='ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_Password']")).sendKeys("Holiday980");
         nop_com.findElement(By.xpath("//*[@id='ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_ConfirmPassword']")).sendKeys("Holiday980");
       // nop_com.findElement(By.id("ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_Password")).sendKeys("hi525");

        //CLICK BUTTON FOR fINISH//
        nop_com.findElement(By.xpath("//*[@id='ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm___CustomNav0_StepNextButton']")).click();
     //   nop_com.close();

    }
}
