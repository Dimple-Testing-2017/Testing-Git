import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

import java.util.concurrent.TimeUnit;

/**
 * Created by ATMIYA2020 on 09/07/2017.
 */
public class Ebay_page {

    public static void main(String args[])
    {

        WebDriver ebay_drive = new FirefoxDriver();
        //IT WILL OPEN WEBPAGE AND MAXIMIZE IT //
        ebay_drive.manage().window().maximize();
        ebay_drive.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);

        ebay_drive.get("https://reg.ebay.co.uk/reg/PartialReg?siteid=3&UsingSSL=1&co_partnerId=2&errmsg=&src=&signInUrl=https%3A%2F%2Fsignin.ebay.co.uk%3A443%2Fws%2FeBayISAPI.dll%3FSignIn%26ru%3D&rv4=1");

        //USING XPATH FIND THE WEB ELEMENTS HERE //

        ebay_drive.findElement(By.xpath("//*[@id='firstname']")).sendKeys("lol1");
        ebay_drive.findElement(By.xpath("//*[@id='lastname']")).sendKeys("Patel1");
        ebay_drive.findElement(By.xpath("//*[@id='email']")).sendKeys("dimplesontu@gmail.com");
        ebay_drive.findElement(By.xpath("//*[@id='PASSWORD']")).sendKeys("holiday***1");
        ebay_drive.findElement(By.linkText("Register")).click();

        //ebay_drive.findElement(By.xpath("//*[@id='ppaFormSbtBtn']")).click();
        //ebay_drive.findElement(By.linkText("Register")).click();
        //ebay_drive.findElement(By.id("id=\"ppaFormSbtBtn\"")).click();
        //ebay_drive.findElement(By.xpath("//input[contains(@id,'ppaFormSbtBtn')]")).click();

        String expected="WANT TO JOIN AS A BUSINESS?";
        String actual= ebay_drive.findElement(By.xpath("//div[@id=\"mainContent\"]/div/div")).getText();

        Assert.assertEquals("WANT TO JOIN AS A BUSINESS?","WANT TO JOIN AS A BUSINESS?");
        // IT WILL CLOSE ALL WEBPAGES //
        //ebay_drive.quit();




    }
}
