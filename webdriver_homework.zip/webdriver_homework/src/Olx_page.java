import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.concurrent.TimeUnit;

/**
 * Created by ATMIYA2020 on 12/07/2017.
 */
public class Olx_page {


    public static void main(String args[]) {
        WebDriver olx_driver = new FirefoxDriver();
        olx_driver.manage().window().maximize();
        olx_driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        //ON HOMEPAGE SELECTING THE COUNTRY HERE //
        olx_driver.get("https://www.olx.com/");
        olx_driver.findElement(By.linkText("India")).click();

        //CLICK ON MY ACCOUNT LINK HERE //
        olx_driver.findElement(By.xpath(".//*[@id='my-account-link']")).click();
        olx_driver.findElement(By.linkText("Register")).click();

        olx_driver.findElement(By.xpath(".//*[@id='userEmail']")).sendKeys("9786020265");
        olx_driver.findElement(By.xpath(".//*[@id='userPass']")).sendKeys("holidayenjoy10");
        olx_driver.findElement(By.xpath(".//*[@id='userPass-repeat']")).sendKeys("Dimple");

        //WE DON'T NEED TO CLICK AND SELECT TERMS AND CONDITION THAT'S WHY IT'S IN COMMENT //
       // olx_driver.findElement(By.xpath(".//*[@id='acceptCheck']")).click();
        olx_driver.findElement(By.xpath(".//*[@id='se_userSignIn']")).click();

        olx_driver.close();



    }
}
