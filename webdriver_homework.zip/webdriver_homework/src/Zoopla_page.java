import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.concurrent.TimeUnit;

/**
 * Created by ATMIYA2020 on 12/07/2017.
 */
public class Zoopla_page {

    public static void main(String args[]) {
        WebDriver zoopla_driver = new FirefoxDriver();
        zoopla_driver.manage().window().maximize();
       // zoopla_driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);

        zoopla_driver.get("https://www.zoopla.co.uk/");
        zoopla_driver.findElement(By.linkText("Sign in")).click();
        zoopla_driver.findElement(By.linkText("Register")).click();

        zoopla_driver.findElement(By.xpath(".//*[@id='register_email']")).sendKeys("Holiday2010@yahoo.com");
        zoopla_driver.findElement(By.xpath(".//*[@id='register_email_confirm']")).sendKeys("Holiday2010@yahoo.com");

        zoopla_driver.findElement(By.xpath(".//*[@id='register_password']")).sendKeys("fun123");
        zoopla_driver.findElement(By.xpath(".//*[@id='']")).sendKeys("");

        //ABOUT ME SELECT //
        //about us select is not working on site need to check it out//
        Select zoopla_obj = new Select(zoopla_driver.findElement(By.xpath("//*[@id='sender_property_status']")));
        zoopla_obj.selectByIndex(8);

        zoopla_driver.findElement(By.xpath("//*[@id='signin_remember']")).click();
        zoopla_driver.findElement(By.xpath("//*[@id='signin_submit']")).click();



    }
}
