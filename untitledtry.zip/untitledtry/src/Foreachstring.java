import java.util.Scanner;

/**
 * Created by ATMIYA2020 on 27/07/2017.
 */
public class Foreachstring {

    public static void main(String args[])
    {

        String arr[] = new String[5];
        Scanner scn = new Scanner(System.in);

        // INSERT THE STRING VALUE IN ARRAY  //

        for( int i=0; i<5; i++)
        {
            System.out.println("Enter string here -->");
            arr[i] = scn.next();
        }

        //PRINTING VALUE   //

        System.out.println("PRINTING THE VALUES OF ARRAY ");

        for(String  x: arr)
        {
            System.out.println("Array element is -->" + x);
        }

    }
}
