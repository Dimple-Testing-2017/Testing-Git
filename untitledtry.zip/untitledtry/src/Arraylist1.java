import java.util.ArrayList;

/**
 * Created by ATMIYA2020 on 27/07/2017.
 */
public class Arraylist1 {

    public static void main(String args[])
    {
        //Array list declaration //
        ArrayList al = new ArrayList();

        // GET THE SIZE OF ARRAY LIST //
        //System.out.println("The size of Array List is --> "+ al.size());

        // ADD VALUE TO THE ARRAY LIST //
        al.add("Family");
        al.add("3");
        al.add("Dimple");
        al.add("Ananya");
        al.add("Parmesh");
        al.add("Swamiji");
        al.add(1,"are");
        al.add(0,"We");

            System.out.println("After Insert value the size of Array List is --> "+ al.size());
            for(Object i:al)
            {
                System.out.println("Value -->" + i);
            }
       // CHANGE THE VALUE IN SPECIFIC POSITIONS  //
            System.out.println("************              After Set the Value  **************  ");
            al.set(7,"Jay Swaminarayan");
            for(Object i:al)
            {
                System.out.println("Value -->" + i);
            }
       // CONTAINS METHOD USAGE  //
        for(Object i: al)
            {
                if(al.contains("Jay Swaminarayan"))
                {
                    System.out.println("\nArray list Contains 'Jay swaminarayan'\n" );
                    break;
                }
                else
                {
                    System.out.println("Jay swaminarayan Not found");
                }

            }

        //REMOVING ARRAYLIST ELEMENTS //
             al.clear();

        System.out.println("After Remove the size of Array List is --> "+ al.size());




    }
}
