import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

import java.util.Scanner;

class Foreach {
    public static void main(String args[]) {

        //ARRAY DECLARATION
            int i[] = new int[4];

            Scanner scanner = new Scanner(System.in);
           //GETTING DATA FROM USER BY FOR EACH   //
           for (int j : i)
            {
            System.out.println("Please enter the number -->");
            i[j] = scanner.nextInt();
            }

            // PRINTING DATA  //
           System.out.println("***************       PRINTING ARRAY DATA HERE  *************************** ");
           for ( int j : i)
           {
               System.out.println("Result of the Array is -->" +  j);
           }

    }
}