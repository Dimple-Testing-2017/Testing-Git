package SoftTest;

import org.openqa.selenium.WebDriver;

/**
 * Created by ATMIYA2020 on 30/07/2017.
 */
public class BasePage {
    protected static WebDriver driver;

}
