package SoftTest;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utils extends BasePage {

       // public static WebDriver _river;
        public WebDriverWait wait;
        public Actions actions;

        /* ALWAYS STATIC METHOD IN UTIL CLASS */
       //*********************************      MY UTILITY METHODS START HERE  ********************************************************//

          // RANDON NUMBER //
        public static String randomNumberEmail()
        {
            DateFormat format = new SimpleDateFormat("ddMMMYYYYmmss");
            return format.format(new Date());
        }

      // IT WILL CLEAR THE TEXT BOX AND FILL THE ENTRY   //
        public static void clearAndFill(By by,String txt)
        {
          driver.findElement(by).clear();
          driver.findElement(by).sendKeys(txt);
        }

        // CLICK ON HOMEPAGE REGISTER LINK  AND OTHER BUTTONS//
        public static void clickElement(By by)
        {
            driver.findElement(by).click();
        }

        // FOR SELECT THE DATE  ON REGISTRATION PAGE //
        public static void selectFromListByTextValue(By element,String txt_value)
        {
            new Select(driver.findElement(element)).selectByVisibleText(txt_value);
        }
     }
