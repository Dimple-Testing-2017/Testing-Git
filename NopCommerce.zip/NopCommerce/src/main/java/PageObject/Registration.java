package PageObject;

import SoftTest.BasePage;
import SoftTest.Utils;
import org.junit.Assert;
import org.openqa.selenium.By;

import static SoftTest.Utils.clearAndFill;

public class Registration extends BasePage {

         String firstname = "Dimple";
         String lastname = "Patel";
         String company = "ABC Export LTD";
         String password = "holiday2000";

         private By genderField = By.id("gender-female");
         private By firstnameField = By.id("FirstName");
         private By lastnameField = By.id("LastName");
         private By dayField = By.name("DateOfBirthDay");
         private By monthField = By.name("DateOfBirthMonth");
         private By yearField = By.name("DateOfBirthYear");
         private By emailField = By.id("Email");
         private By companyField = By.id("Company");
         private By newsletterField = By.id("Newsletter");
         private By passwordField = By.id("Password");
         private By confirmPasswordField = By.id("ConfirmPassword");
         private By buttonClick = By.id("register-button");

         public void assertRegisterpage()
         {
             Assert.assertTrue(driver.getTitle().contains("nopCommerce demo store. Register"));
         }

         public void userRegistration()
         {
             assertRegisterpage();
             boolean news = true;
             Utils.clickElement(genderField);
             clearAndFill(firstnameField,firstname);
             clearAndFill(lastnameField,lastname);

             Utils.selectFromListByTextValue(dayField,"15");
             Utils.selectFromListByTextValue(monthField,"June");
             Utils.selectFromListByTextValue(yearField,"2000");
             Utils.clearAndFill(emailField,firstname+Utils.randomNumberEmail()+"@gmail.com");
             Utils.clearAndFill(companyField,company);

             if(driver.findElement(By.id("Newsletter")).isSelected())
             {
                Utils.clickElement(newsletterField);
             }
             Utils.clickElement(newsletterField);
             Utils.clearAndFill(passwordField,password);
             Utils.clearAndFill(confirmPasswordField,password);
             Utils.clickElement(buttonClick);

             Assert.assertTrue(driver.getPageSource().contains("Your registration completed"));
         }

}
