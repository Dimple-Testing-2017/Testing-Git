package PageObject;

import SoftTest.BasePage;
import SoftTest.Utils;
import org.junit.Assert;
import org.openqa.selenium.By;

public class EmailaFriend_WithoutRegistration extends BasePage
{
    private By friendsemail_field = By.id("FriendEmail");
    private By youremail_field = By.id("YourEmailAddress");
    private By message_field  = By.id("PersonalMessage");

    public void navigateToEmailAFriend()
    {
        Assert.assertTrue(driver.getPageSource().contains("Email a friend"));
        Utils.clearAndFill(friendsemail_field,"holiday2000@gmail.com");
        Utils.clearAndFill(youremail_field,"dpatel200@gmail.com");
        Utils.clearAndFill(message_field,"This is Try of sending E-mails on site. Well come to send the details of the friends. Thank you very much.");
        Utils.clickElement(By.name("send-email"));
        Assert.assertTrue(driver.getPageSource().contains("Only registered customers can use email a friend feature"));

    }

}
