package PageObject;

import SoftTest.BasePage;
import SoftTest.Utils;
import org.junit.Assert;
import org.openqa.selenium.By;

public class HomePage extends BasePage
{
     public void homepageAssertCheck()
     {
         Assert.assertTrue(driver.getTitle().contains("nopCommerce demo store"));
     }

    public void navigateToRegistrationPage()
    {
        homepageAssertCheck();
        Utils.clickElement(By.linkText("Register"));
    }
}
