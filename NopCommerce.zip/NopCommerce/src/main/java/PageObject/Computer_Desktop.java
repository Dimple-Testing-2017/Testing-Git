package PageObject;

import SoftTest.BasePage;
import SoftTest.Utils;
import org.junit.Assert;
import org.openqa.selenium.By;

public class Computer_Desktop extends BasePage
{
    public void navigateToComputerDesktopPage()
    {
        Utils.clickElement(By.linkText("Computers"));
        Assert.assertTrue(driver.getTitle().contains("Computers"));

        //driver.manage().timeouts().
        Utils.clickElement(By.linkText("Desktops"));
        Assert.assertTrue((driver.getTitle().contains("Desktops")));

        Utils.clickElement(By.linkText("Build your own computer"));
        Assert.assertTrue(driver.getPageSource().contains("Build your own computer"));

        Utils.clickElement(By.xpath(".//*[@id='product-details-form']/div/div[1]/div[2]/div[10]/div[3]/input"));

    }

}
