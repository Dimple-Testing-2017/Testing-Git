package SoftTest;

import PageObject.*;
import org.testng.annotations.Test;

public class TestSuite extends BaseTest
{
       // HERE ALL THE LOCATORS AND ALL  WEB ELEMENTS WE ARE  USING ALL LOGIC FOR ACCESING NOP COMMERCE GOING HERE//
       Registration registration = new Registration();
       HomePage homepage = new HomePage();
       Computer_Desktop computer_desktop = new Computer_Desktop();
       Email_a_friend emails = new Email_a_friend();
       EmailaFriend_WithoutRegistration withoutregistration = new EmailaFriend_WithoutRegistration();

    @Test(priority = 0)
      public void main()
      {
           //E-MAIL A FRIEND WITH REGISTRATION  //
            homepage.navigateToRegistrationPage();
            registration.userRegistration();
            computer_desktop.navigateToComputerDesktopPage();
            emails.navigateToEmailAFriend();
      }

     @Test(priority = 1)
     public void withoutRegistration()
     {
         //E-MAIL A FRIEND WITHOUT REGISTRATION  //
         computer_desktop.navigateToComputerDesktopPage();
         withoutregistration.navigateToEmailAFriend();
     }
  }
