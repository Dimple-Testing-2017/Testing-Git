import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import javax.xml.ws.Action;

/**
 * Created by ATMIYA2020 on 18/07/2017.
 */
public class Amazon {
    public WebDriver driver = null;

    @Test
    public void test() {

        driver = Container.setup(driver);
        driver.get("https://www.amazon.co.uk/");

        //HOVER THE YOUR ACCOUNT AND CLICK ON START HERE FOR REGISTRATION //

        WebElement element = driver.findElement(By.id("nav-link-yourAccount"));
        Actions action = new Actions(driver);
        action.moveToElement(element).build();
        driver.findElement(By.linkText("Start here.")).click();

        //REGISTRATION PAGE DATA ENTER FROM HERE //
        driver.findElement(By.xpath(".//*[@id='ap_customer_name']")).sendKeys("Krishna");
        driver.findElement(By.name("email")).sendKeys("holidayKrishna111@gmail.com");
        driver.findElement(By.name("password")).sendKeys("holiday1234");
        driver.findElement(By.name("passwordCheck")).sendKeys("holiday1234");
        driver.findElement(By.id("continue")).click();

        //ASSERT EQUALS HERE
        String actual = driver.findElement(By.id("hud-customer-name")).getText();
        Assert.assertEquals(actual, "Krishna's" + "\n" + "Amazon","Test case is executed");

    }

    @AfterTest
    public void aftertest()
    {
         driver.close();
         driver.quit();
    }

}