import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import java.util.concurrent.TimeUnit;
import static org.testng.Assert.assertNotNull;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;
import static org.testng.Assert.assertNotNull;

public class Sky {

    public WebDriver driver = null;

    @BeforeTest
    public void before_test()
    {
        driver = Container.setup(driver);
        driver.get("https://www.sky.com/");
    }

    @Test
     public void test_start()
     {
           // IT WILL CLICK ON SIGN IN IN HOMEPAGE AND THEN SIGN UP ON SECOND PAGE THE ON REGISTRATION PAGE //
            driver.findElement(By.linkText("Sign In")).click();
            driver.findElement(By.linkText("Sign up")).click();

            // IT IS STARTING TO FILL FORM   //
            Select select = new Select(driver.findElement(By.xpath(".//*[@id='title']")));
            select.selectByVisibleText("Mrs");

            driver.findElement(By.xpath(".//*[@id='firstname']")).sendKeys("Divya");
            driver.findElement(By.xpath(".//*[@id='lastname']")).sendKeys("Patel");
            driver.findElement(By.xpath(".//*[@id='email']")).sendKeys("Holiday2011@yahoo.com");
            driver.findElement(By.xpath(".//*[@id='confirmEmail']")).sendKeys("Holiday2011@yahoo.com");
            driver.findElement(By.xpath(".//*[@id='password']")).sendKeys("havefun123");
            driver.findElement(By.xpath(".//*[@id='confirmPassword']")).sendKeys("havefun123");
            driver.findElement(By.xpath(".//*[@id='captcha']")).getAttribute("disabled");



            // FOR CHECKBOX CLICK //
            driver.findElement(By.xpath(".//*[@id='termsAndConditions']")).click();
            driver.findElement(By.xpath(".//*[@id='marketingOptOut']")).click();

            // FOR BUTTON CLICK //
            driver.findElement(By.xpath(".//*[@id='submitButton']")).click();

            Assert.assertEquals(driver.findElement(By.xpath(".//*[@id='feedbackLink']")).getText(),"Feedback","Text is match");

        }

   @AfterTest
    public void aftertest()
   {
      driver.close();
      driver.quit();
   }

}
