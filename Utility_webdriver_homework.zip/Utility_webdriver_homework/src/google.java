import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import sun.java2d.opengl.WGLSurfaceData;

/**
 * Created by ATMIYA2020 on 18/07/2017.
 */
public class google {

    WebDriver driver=null;

    @BeforeTest
    public void beforetest()
    {
        driver = Container.setup(driver);
        driver.get("https://www.google.co.uk");
    }

    @Test
    public void googlepage()
    {
        String expected = "Create your Google Account";

        driver.findElement(By.linkText("Gmail")).click();
        //driver.findElement(By.linkText("Create an account")).click();
        driver.findElement(By.linkText("CREATE AN ACCOUNT")).click();
        // HERE START TO FILL A FORM DATA //
        driver.findElement(By.id("FirstName")).sendKeys("Dimple");
        driver.findElement(By.id("LastName")).sendKeys("Patel");
        driver.findElement(By.id("GmailAddress")).sendKeys("holidayfun2010@gmail.com");
        driver.findElement(By.id("Passwd")).sendKeys("holiday123*");
        driver.findElement(By.id("PasswdAgain")).sendKeys("holiday123*");
        driver.findElement(By.id("BirthMonth")).sendKeys("July");
        driver.findElement(By.id("BirthDay")).clear();
        driver.findElement(By.id("BirthDay")).sendKeys("22");
        driver.findElement(By.id("BirthYear")).clear();
        driver.findElement(By.id("BirthYear")).sendKeys("2000");
        driver.findElement(By.xpath(".//*[@id='Gender']/div[1]")).sendKeys("Female");
        driver.findElement(By.xpath("//input[@id='RecoveryPhoneNumber']")).sendKeys("7722576154");
        driver.findElement(By.xpath("//input[@id='RecoveryEmailAddress']")).sendKeys("holiday2010@gmail1.com");
        driver.findElement(By.xpath(".//*[@id='CountryCode']/div[1]")).sendKeys("Honduras");
        driver.findElement(By.xpath("//input[@id='submitbutton']")).click();

    }

    @AfterTest
     public void testexit() {
        driver.close();
        driver.quit();
    }

}
