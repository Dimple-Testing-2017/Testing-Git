import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.concurrent.TimeUnit;
public class Thetimes
{
    public WebDriver driver = null;

     @BeforeTest
     public void beforerun()
     {
            driver = Container.setup(driver);
     }

     @Test
     public void test_execute()
     {
            driver.get("https://join.thetimes.co.uk");
            driver.findElement(By.xpath("//div[@id=\"a3J200000004RKBEA2\"]/div/div/button")).click();
            driver.get("https://join.thetimes.co.uk");

            // FOR TITTLE SELECTING WITH SELECT //
            Select select_obj = new Select(driver.findElement(By.xpath("//*[@id='title']")));
            select_obj.selectByVisibleText("Mrs");

            driver.findElement(By.xpath("//*[@id='firstName']")).sendKeys("Ananya");
            driver.findElement(By.xpath("//*[@id='lastName']")).sendKeys("Patel");
            driver.findElement(By.xpath("//*[@id='email']")).sendKeys("holiday2000@gmail.com");
            driver.findElement(By.xpath("//*[@id='confirmEmail']")).sendKeys("holiday2000@gmail.com");
            driver.findElement(By.xpath("//*[@id='password']")).sendKeys("fun2000enjoy");
            driver.findElement(By.xpath("//*[@id='confirmPassword']")).sendKeys("fun2000enjoy");

            //BY INDEX working here PERFECT //
            Select dob = new Select(driver.findElement(By.xpath("//*[@id='dateOfBirthDay']")));
            dob.selectByIndex(15);


            //BY INDEX NOT WORKING SO I TOOK BY VISIBLE TEXT HERE //
            Select month = new Select(driver.findElement(By.xpath("//*[@id='dateOfBirthMonth']")));
            month.selectByVisibleText("May");

            // I TOOK BY VISIBLE TEXT HERE \AS WELL VALUE WORKING GOOD//
            Select year = new Select(driver.findElement(By.xpath("//*[@id='dateOfBirthYear']")));
            year.selectByValue("1995");
            driver.findElement(By.xpath("//*[@id='phone']")).sendKeys("07898876534");

            // FOR BUTTON //
            driver.findElement(By.xpath("//*[@id='accountCreationButton']")).click();
            // AFTER REGISTRATION PAGE 1 PAGE2 HAVE CARD DETAILS SO I DID STOP TO PROCESS //
        }

    @AfterMethod
    public void aftermethod()
    {
        String actual = driver.findElement(By.xpath(".//*[@id='paymentHeader']/div/h4")).getText();
        Assert.assertEquals( actual,"Choose a payment method","Text is match --> ");
    }

    @AfterTest
    public void close()
    {
       // driver.close();
       // driver.quit();
    }


}



