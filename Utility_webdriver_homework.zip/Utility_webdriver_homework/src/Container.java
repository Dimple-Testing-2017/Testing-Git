/*
 THIS IS UTILITY CLASS HERE
 */

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;


import java.util.concurrent.TimeUnit;

public final class Container {
    // WE DON'T NEED TO MAKE ANY OBJECT OF THIS CLASS AS WELL CREATE STATIC METHODS HERE //

    public static WebDriver driver;

         //DRIVER LOADING METHOD START HERE //


   public static WebDriver setup(WebDriver driver)
   {
       if(driver == null) {
           driver = new FirefoxDriver();
           driver.manage().deleteAllCookies();
           driver.manage().window().maximize();
           driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
           return driver;
       }else
          return driver;

         //System.out.println("in method "+ driver.getTitle() );

   }
       //DRIVER LOADING METHOD END HERE //

    public static void exit()
       {
           driver.close();
           driver.quit();
       }

    // *********************************    UN USED METHODS START FROM HERE  ************************************************* //

    /*
    public static void dropdownlist(WebDriver driver, By by, String value)
    {
        Select select = new Select(driver.findElement(by));
        select.selectByValue(value);
    }


    public static void dropdownlist(WebDriver driver, By by, int value)
    {
         Select select = new Select(driver.findElement(by));
         select.selectByIndex(value);
    }


    public static void dropdownlist(WebDriver driver, By by, String value)
    {
        Select select = new Select(driver.findElement(by));
        select.selectByVisibleText(value);
    }

    public static void checkRadio(WebDriver driver, By by)
    {
		WebElement inputElement = driver.findElement(by);
		inputElement.click();
	}

     public static void goToTab(WebDriver driver, By by) {
		waitUntilClickable(driver, by);
		driver.findElement(by).click();
	}

	public static WebElement waitForVisibility(WebDriver driver, By by) {
		return waitForVisibility(driver, by, 45);
	}

	public static boolean isEnabled(WebDriver driver, String eachField) {
		return (driver.findElement(By.id(eachField)).isEnabled());
	}

	public static boolean isDisabled(WebDriver driver, String eachField) {
		return (!driver.findElement(By.id(eachField)).isEnabled());
	}

	public static boolean isVisible(WebDriver driver, String eachField) {
		return (driver.findElement(By.id(eachField)).isDisplayed());
	}

	public static boolean isInvisible(WebDriver driver, String eachField) {
		return (!driver.findElement(By.id(eachField)).isDisplayed());
	}

    public static void populateTextBox(WebDriver driver, By by, String value) {
		WebElement inputElement = driver.findElement(by);
		if ("".equals(value)) {
			inputElement.clear();
		} else {
			inputElement.sendKeys(value);
		}
	}

    */


}
