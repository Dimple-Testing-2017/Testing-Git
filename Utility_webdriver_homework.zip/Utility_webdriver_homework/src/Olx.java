import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Olx
{
    public WebDriver driver = null;

    @BeforeMethod

    public void before()
    {
        driver = Container.setup(driver);
        driver.get("https://www.olx.com");
    }

    @Test
    public void textexecute()
    {
        //ON HOMEPAGE SELECTING THE COUNTRY HERE //
        driver.findElement(By.linkText("India")).click();

        //CLICK ON MY ACCOUNT LINK HERE //
        driver.findElement(By.xpath(".//*[@id='my-account-link']")).click();
        driver.findElement(By.linkText("Register")).click();
        driver.findElement(By.xpath(".//*[@id='userEmail']")).sendKeys("9786020265");
        driver.findElement(By.xpath(".//*[@id='userPass']")).sendKeys("holidayenjoy10");
        driver.findElement(By.xpath(".//*[@id='userPass-repeat']")).sendKeys("Dimple");

        //WE DON'T NEED TO CLICK AND SELECT TERMS AND CONDITION THAT'S WHY IT'S IN COMMENT //
        driver.findElement(By.xpath(".//*[@id='se_userSignIn']")).click();
    }

    @AfterTest
    public void aftertest()
    {
        String expected="India's Largest Marketplace";
        String actual = driver.findElement(By.xpath("//*[@id='header-container']/div[1]/div/span")).getText();
        Assert.assertEquals(actual,expected,"String Match");
    }

     @AfterMethod
     public void close()
     {
         //driver.close();
         //driver.quit();
     }

  }



