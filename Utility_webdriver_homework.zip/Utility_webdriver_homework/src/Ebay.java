import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import java.util.concurrent.TimeUnit;

/**
 * Created by ATMIYA2020 on 17/07/2017.
 */
public class Ebay {
    WebDriver driver=null;


    @Test
    public void testlogic()
    {

        driver=Container.setup(driver);
        driver.get("https://www.ebay.co.uk");
        driver.findElement(By.linkText("register")).click();
        driver.findElement(By.name("firstname")).sendKeys("divya");
        driver.findElement(By.name("lastname")).sendKeys("patel");
        driver.findElement(By.name("email")).sendKeys("dimplesontu@yahoo.com");
        driver.findElement(By.xpath(".//*[@id='PASSWORD']")).sendKeys("holiday123*");
        driver.findElement(By.xpath(".//*[@id='ppaFormSbtBtn']")).click();

        String actual = driver.findElement((By.xpath(".//*[@id='mainContent']/div[3]/div"))).getText();
        Assert.assertEquals(actual,"WANT TO JOIN AS A BUSINESS?");
    }

    @AfterTest
    public void close()
    {
     driver.close();
     driver.quit();
    }

}