/*
WAP to input student name, roll no, 3 subjects marks..and find out total, percentage and result if
    he is pass or fail on basis of percentage (pass>=35) and also give them grade
    >= 80 A+
    >= 60 A
    >= 50 B
    >= 35 C
    pass or fails on the basis of..student needs to pass all the subjects
 */
import java.util.Scanner;
public class Programe_4 {

       //    *****************       MAIN METHOD START HERE   ***************** //
        public static void main(String args[]) {
            Scanner scanner = new Scanner(System.in);
            int r_no,chemistry, biology, maths, total;
            double percentage;
            String name;

            System.out.println("Please enter the Student Name --> ");
            System.out.print(System.in);
            name = scanner.next();

            System.out.println("Please enter the Roll Number --> ");
            System.out.print(System.in);
            r_no = scanner.nextInt();

            System.out.println("Please enter Chemistry marks --> ");
            System.out.print(System.in);
            chemistry = scanner.nextInt();

            System.out.println("Please enter Biology marks --> ");
            System.out.print(System.in);
            biology = scanner.nextInt();

            System.out.println("Please enter Maths marks --> ");
            System.out.print(System.in);
            maths = scanner.nextInt();

            // PRINTING MARKSHEET HEADING //
            System.out.println("\n\t\t\t\t\t\t\t\t\t\t  STUDENT MARKSHEET   \t \t \t \t ");
            System.out.println("******************************************************************************************************************");
            System.out.println("Student name \t\t Roll number \t\t Chemistry \t\t Biology \t\t Maths \t\t Total \t\t Persentage" );
            System.out.println("------------------------------------------------------------------------------------------------------------------");


            // CHECKING IN ALL SUBJECT PASS OR FAIL //
            if( chemistry>35 && biology>35 && maths >35 )
            {
                // PASS STUDENT PRINT RECORD   //
                total = chemistry + biology + maths;
                percentage = total / 3;

                // CHECKING GRADES //
                if (percentage >= 80)
                {
                    System.out.println(name + " get A+ Grade");
                } else if (percentage >= 60)
                    {
                        System.out.println(name + " get A Grade");
                    } else if (percentage >= 50)
                        {
                            System.out.println(name +" get B Grade");
                        } else if (percentage >= 35)
                            {
                            System.out.println(name + " get C Grade");
                            }
                System.out.println(name+"\t\t\t     " +r_no+ "\t\t\t\t\t" +chemistry+ "\t\t\t\t" +biology + "\t\t\t " +maths+ " \t\t\t" +total+ " \t\t\t" + percentage);
                System.out.println("*******************************************************************************************************************");
             }
            else
                {
                    // FOR FAILS STUDENT PRINT RECORD //
                    total = chemistry + biology + maths;
                    percentage = total / 3;
                    System.out.println(name+"\t\t\t     " +r_no+ "\t\t\t\t\t" +chemistry+ "\t\t\t\t" +biology + "\t\t\t " +maths+ " \t\t\t" +total+ " \t\t\t" + percentage);
                    System.out.println("*******************************************************************************************************************");
                    System.out.println(name +" is Fail");
                }

            //    *****************       MAIN METHOD END HERE   ***************** //
        }
    }


