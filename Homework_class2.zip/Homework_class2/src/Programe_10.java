/*  Input any alphabet from a to f and print their city name accordingly (use if else) any other
      alphabet should be invalid entry
 */

import java.util.Scanner;
public class Programe_10 {

    // MAIN METHOD DECLARATION //
    public static void main(String args[])
    {
       char c;
       String s;

       //SCANNER CLASS OBJECT CREATING AND ASKING VALUE FROM USER //
       Scanner scanner = new Scanner(System.in);
       System.out.print(System.in);

       System.out.println("Please enter the Character start from letter A TO F --> ");

       // WE CAN GET HERE STRING INPUT FROM USER //
             s = scanner.next();

         // HERE WE CAN GET 1 CHARACTER FROM STRING BY USING CHARAT() METHOD AND STORE AS A CHARACTER//
         /* GETTING FIRST CHARACTER FROM STRING BCOZ SCANNER CLASS DON'T HAVE ANY METHOD FOR GETTING CHARACTER VALUE FROM STRING SO WE ARE GETTING
           STRING VALUE FROM USER AND THEN GET FIRST CHARACTER FROM STRING          */
             c = s.charAt(0);

       //System.out.println(s +" c is " + c);

        //COMPARING FIRST LETTER STARTS FROM A TO F //

        if(c=='a' || c=='A')
            {
                System.out.println("User type A letter and city start from A is --> Atlanta");
            }
             else if(c=='b' || c=='B')
             {
                 System.out.println("User type B letter and city start from B is --> Boston");
             }
                else if(c=='c' || c=='C')
                {
                      System.out.println("User type C letter and city start from C is --> Chicago");
                }
                else if(c=='d' || c=='D')
                    {
                        System.out.println("User type D letter and city start from D is --> Delhi");
                    }
                    else if(c=='e' || c=='E')
                        {
                            System.out.println("User type E letter and city start from E is --> Edinburgh");
                        }
                        else if(c=='f' || c=='F')
                        {
                            System.out.println("User type F letter and city start from F is --> Faridabad");
                        }
                        else
                        {
                            System.out.println("Please enter valid Character");
                        }

    }

}

