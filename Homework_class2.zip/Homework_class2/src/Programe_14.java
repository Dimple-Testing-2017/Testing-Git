/* 17. WAP input any number, the print Day name of the week accordingly by using (if else) */

import java.util.*;
import java.util.Calendar;
public class Programe_14 {

    // MAIN METHOD START HERE //
    public static void main(String args[])
    {
        // VARIABLE DECLARATION HERE //
        int a;

        // SCANNER CLASS AND CALENDER CLASS OBJECT CREATING //
            Scanner scanner = new Scanner(System.in);
            Calendar calendar = Calendar.getInstance();

        // ASKING VALUE FROM USER HERE //
           System.out.println("Please enter any Digital value --> ");
           a=scanner.nextInt();

        //IT WILL SET USER DIGIT VALUE TO CONVERT IT IN DAY AND SET TO SYSTEM ALSO WORKING WITH CURRUENT YEAR //
           calendar.set(Calendar.YEAR,a);

        //  IT WILL CHECK USER DIGIT VALUE TO WEEKDAY VALUE//

         if(a==0)
           {        System.out.println("The day of the week is --> Sunday");           }
           else if(a==1)
                {     System.out.println("The day of the week is --> Monday");           }
               else if(a==2)
                   {       System.out.println("The day of the week is --> Tuesday");        }
                   else if(a==3)
                      {        System.out.println("The day of the week is --> Wednesday");      }
                       else if(a==4)
                           {         System.out.println("The day of the week is --> Thursday");     }
                           else if(a==5)
                              {         System.out.println("The day of the week is --> Friday");      }
                               else if(a==6)
                                  {          System.out.println("The day of the week is --> Saturday");     }

    }
    //  MAIN METHOD END HERE //
}
