/*  Enter any one digit value and the find out if it is number or an alphabet or symbol  */




                                        // THIS PROGRAMME HAVE NOT FINISH YET SO DON'T COUNT IT. //








/*
import java.util.Scanner;

public class Programe_13 {

    // MAIN METHOD DECLARATION  //
    public static void main(String args[])
    {
        String s;
        char c;
        int i;
        int d=65,e=90;

        //SCANNER CLASS OBJECT CREATION //
        Scanner scanner = new Scanner(System.in);
        System.out.print(System.in);

        // GET THE ANY DIGIT FROM USER //
        System.out.println("Please enter any Value");
        s = scanner.next();
        c = s.charAt(0);
        i=(int)c;

        // CHECKING FOR ALPHABET VALUE
        for(d=65; d<=90; d++)
        {
            if(i==d)
            {
                System.out.println("The Digit enter by User is Uppercase Alphabet--> " + c);
            }

        }


    }
}

*/
22