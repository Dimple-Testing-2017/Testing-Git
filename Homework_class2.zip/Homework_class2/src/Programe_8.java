/*      WAP to input any number and find out if its odd or even (turnery operator (:?))      */

import java.util.Scanner;
public class Programe_8{

    public static void main(String args[])
    {
        int a,z;

        // CREATING SCANNER CLASS OBJECT HERE //
        Scanner scanner = new Scanner(System.in);
        System.out.print(System.in);

        System.out.println("Please enter any Number for checking Odd or Even -->");
        a = scanner.nextInt();

        // ASSIGN THE Z VALUE BY 1 OR 0 AFTER CHECKING VALUE OF A%2 == 0 //
        z = (a%2==0) ? 1: 0;

        // CHECKING Z VALUE //
        if(z==1)
        {
            System.out.println(a + " Number is Even.");
        }
        else
        {
            System.out.println(a + " Number is Odd.");
        }

    }

}
