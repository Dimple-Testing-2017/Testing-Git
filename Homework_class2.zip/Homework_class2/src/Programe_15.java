/*     Write a Java program that takes the user to provide a single character from the
      alphabet. Print Vowel or Consonant, depending on the user input. If the user input
      is not a letter (between a and z or A and Z), or is a string of length > 1, print an
      error message.
    For eg:
        Input an alphabet: p
        Expected Output :
        Input letter is Consonant
 */
import java.util.Scanner;
public class Programe_15 {

    // main method start here //
    public static void main(String args[])
    {
        String a;
        char c;

        // CREATING OBJECT OF SCANNER CLASS //
            Scanner scanner = new Scanner(System.in);

        // GET CHARACTER VALUE FROM USER //
              a = scanner.next();
              c = a.charAt(0);

        // CHECK STRING IS >1 THEN PRINT ERRO MSG //
             if (a.length()>=2 && a.length()<=9)
             {System.out.println("Please enter a Value should be Single Alphabet Character ");}
              else if(c=='a'|| c=='A')
                 {        System.out.println("This a vowel of English Language. ");          }
                 else if(c=='e'|| c=='E')
                    {         System.out.println("This a vowel of English Language. ");          }
                     else if(c=='i'|| c=='I')
                       {        System.out.println("This a vowel of English Language. ");       }
                       else if(c=='o'|| c=='O')
                         {          System.out.println("This a vowel of English Language. ");        }
                         else if(c=='u'|| c=='U')
                          {               System.out.println("This a vowel of English Language. ");     }
                         else      { System.out.println("This letter is Constant. ");}

    }
    //MAIN METHOD END HERE //
}
