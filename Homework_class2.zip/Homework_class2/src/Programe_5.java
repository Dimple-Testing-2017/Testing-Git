/* WAP to input any two numbers and then print their interchanged value */
import sun.awt.SunHints;

import java.util.Scanner;

public class Programe_5 {

    public static void main(String args[])
    {
        Scanner scanner = new Scanner(System.in);
        int a=0, b=0, c=0,d=0;

        // GETTING VARIABLE A VALUE FROM USER //
        System.out.println("Please enter the Variable A value -->");
        System.out.println(System.in);
        a = scanner.nextInt();

        // GETTING VALUE OF VARIABLE B  FROM USER //
        System.out.println("Please enter the Variable B value -->");
        System.out.println(System.in);
        b = scanner.nextInt();

        // INTERCHANGING THE VALUE OF VARIABLES //
       c=a;
       d=b;

       a=0;
       b=0;

       a=d;
       b=c;

        // PRINTING THE VARIABLES VALUE AFTER INTERCHANGING //
        System.out.println("After Interchange the Value of Variable Result is --> ");
        System.out.println("Value of variable A is --> "+ a);
        System.out.println("Value of variable B is --> "+ b);

    }

}
