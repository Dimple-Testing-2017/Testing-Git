/*  WAP input any five number and then find average of five numbers   */

import java.util.Scanner;

public class Programe_7
{

        public static void main(String args[])
        {
            int a,b,c,d,e,total, averg;

            // SCANNER CLASS OBJECT CREATING //

            Scanner scanner = new Scanner(System.in);
            System.out.print(System.in);

            // ASKING 5 NUMBER VALUE FROM USER //
            System.out.println("Please enter any 5 Numeric value -->");
             a = scanner.nextInt();
             b = scanner.nextInt();
             c = scanner.nextInt();
             d = scanner.nextInt();
             e = scanner.nextInt();

            // COUNTING THE TOTAL OF 5 VALUES //
                total = a + b + c + d + e;
            // COUNTING THE  AVERAGE OF 5 VALUE //
                averg = total / 5;
            // PRINTING THE VALUES OF TOTAL AND AVERAGE VALUE //
            System.out.println("Total of 5 Values -->" + total);
            System.out.println("Average of 5 Values -->" + averg);
        }
}
