/* WAP to input enter any two number and ask user to enter their symbol (+, -, /, *) find addition,
      subtraction, multiplication and division according to their symbol (using if else)
 */
import java.util.Scanner;
public class Programe_12
{
    //MAIN METHOD START FROM HERE //
    public static void main(String args[])
    {
        int a, b, result;
        String s;
        char c;

        // CREATING SCANNER CLASS OBJECT HERE //
        Scanner scanner = new Scanner(System.in);
        System.out.print(System.in);

        // GETTING VARIABLE A AND B VALUE FROM CUSTOMER //
        System.out.println("Please Enter the Variable A value -->");
        a = scanner.nextInt();

        System.out.println("Please Enter the Variable B value -->");
        b = scanner.nextInt();

        System.out.println("Which action you want to perform on both Variables");
        System.out.println(" + -> Addition \t\t - -> Subtraction \t\t * -> Multiplication \t\t / -> Division ");

        s=scanner.next();
        c=s.charAt(0);

        if (c=='+')
        {
            result = a + b;
            System.out.println("Addition of Variable A and B is --> "+ result);
        }
            else if (c=='-')
             {
                   // CHECKING WHICH NUMBER IS GREATER THEN PERFORM ACTION IF B > A THEN B-A //
                     if(a>=b)
                     {
                         result = a - b;
                         System.out.println("Subtraction of Variable A from B is --> " + result);
                     }
                     else
                     {
                         result = b - a;
                         System.out.println("Subtraction of Variable B from A is --> " + result);
                     }
              }
             else if (c=='*')
                {
                    result = a * b;
                    System.out.println("Multiplication of Variable A and B is --> "+ result);
                }
               else if (c=='/')
                {
                    // CHECKING WHICH NUMBER IS GREATER THEN PERFORM ACTION IF B > A THEN B/A //
                    if(a>=b)
                    {
                        result = a / b;
                        System.out.println("Division of Variable A by B is --> " + result);
                    }
                    else
                    {
                        result = b / a;
                        System.out.println("Division of Variable B by A is --> " + result);
                    }

                }
    }
    //MAIN METHOD END HERE //
}
