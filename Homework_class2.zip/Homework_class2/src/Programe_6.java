/*
  WAP to input employee id, name, basic salary then find HRA, TA, DA, PF and Gross salary
    HRA = basic salary 10%
    DA = Basic salary 8%
    TA = Basic salary 9%
    PF= Basic salary 20%
    Gross salary = basic salary + HRA + TA + DA -PF
*/
import sun.invoke.util.VerifyAccess;

import java.util.Scanner;

public class Programe_6 {

    // CALCULATING HRA//

     public double cal_hra(Double hra)
     {
        Double val_hra= hra / 10;
        //System.out.println(val_hra+ "in method");
        return val_hra;
     }
    // CALCULATING DA HERE //
     public double cal_da(Double da)
     {
         Double val_da = da / 8;
         System.out.println(val_da + "in method");
         return val_da;
     }
     // CALCULATING TA HERE //
     public double cal_ta(Double ta)
     {
         Double val_ta= ta / 9;
         return val_ta;
     }
     // CALCULATING PF HERE //
     public Double cal_pf(Double pf)
     {
     Double val_pf = pf / 20;
     return val_pf;
     }

     // CALCULATING GROSS SALARY  //
     public Double cal_gross(Double basic, Double hra, Double ta, Double da,Double pf)
     {
         Double val_gross = basic + hra + da + ta - pf;
         return val_gross;
     }


    //*******************  MAIN METHOD START FROM HERE   *************************** //
    public static void main(String argc[])
    {
        // DECLARING THE VARIABLLE //
        int id;
        Double hra, basic,da,ta,pf,gross;
        String name;

        // CREATING THE SCANNER CLASS OBJECT  //
            Scanner scanner = new Scanner(System.in);
                // CREATING CLASS OBJECT FOR CALLING METHODS  //
                Programe_6 programe_6= new Programe_6();

        // ASKING VALUE OF ID, NAME AND BASICS FROM USER //
        System.out.println("Please enter the Employee ID -> ");
        System.out.print(System.in);
        id =scanner.nextInt();

        System.out.println("Please enter the Employee Name -> ");
        System.out.print(System.in);
        name=scanner.next();

        System.out.println("Please enter the Basic Salary of Employee ->");
        System.out.print(System.in);
        basic = scanner.nextDouble();

        // CALCULATING HRA BY CALLING METHOD//
        hra = programe_6.cal_hra(basic);

        // CALCULATING DA BY CALLING METHOD //
        da = programe_6.cal_da(basic);

        // CALCULATING TA BY CALLING METHOD //
        ta=programe_6.cal_ta(basic);

        // CALCULATING PF BY CALLING METHOD   //
        pf = programe_6.cal_pf(basic);

        gross = programe_6.cal_gross(basic,hra,ta,da,pf);
        System.out.println(" ---------------      Employee Payslip  ----------------------");
        System.out.println("Employee "+ name + " HRA IS --> " + hra);
        System.out.println("Employee "+ name + " DA is --> " + da );
        System.out.println("Employee "+ name + " Ta is --> " + ta);
        System.out.println("Employee "+ name + " PF is --> " + pf);
        System.out.println("Employee "+ name + " Gross Amount is --> " + gross);
    }
    //*****************   MAIN METHOD END HERE  ********************************//
}
