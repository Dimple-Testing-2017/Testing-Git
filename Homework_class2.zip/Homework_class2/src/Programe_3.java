/*
WAP to input student name, roll no, 3 subjects marks..and find out total, percentage and result if
    he is pass or fail on basis of percentage (pass>=35) and also give them grade
    >= 80 A+
    >= 60 A
    >= 50 B
    >= 35 C
*/

import java.util.Scanner;
public class Programe_3 {

           //    *****************       MAIN METHOD START HERE   ***************** //
    public static void main(String args[]) {
        //CREATING SCANNER CLASS OBJECT //
        Scanner scanner = new Scanner(System.in);
        // VARIABLE DECLARATION  //
        int r_no,chemistry, biology, maths, total;
        double percentage;
        String name;
        // ASKING VALUE FROM USER //
        System.out.println("Please enter the Student Name --> ");
        System.out.print(System.in);
        name = scanner.next();

        System.out.println("Please enter the Roll Number --> ");
        System.out.print(System.in);
        r_no = scanner.nextInt();

        System.out.println("Please enter Chemistry marks --> ");
        System.out.print(System.in);
        chemistry = scanner.nextInt();

        System.out.println("Please enter Biology marks --> ");
        System.out.print(System.in);
        biology = scanner.nextInt();

        System.out.println("Please enter Maths marks --> ");
        System.out.print(System.in);
        maths = scanner.nextInt();

        // COUNTING TOTAL AND PERCENTAGE   //
        total = chemistry + biology + maths;
        percentage = total / 3;

        //System.out.println(total);
        //System.out.println(percentage);

        // PRINTING HEADING OF MARKSHEET //

        System.out.println(" \t  \t  \t  \t  STUDENT MARKSHEET \t \t \t \t ");
        System.out.println("******************************************************************************************************************");
        System.out.println("Student name \t\t Roll number \t\t Chemistry \t\t Biology \t\t Maths \t\t Total \t\t Persentage" );
        System.out.println("------------------------------------------------------------------------------------------------------------------");
        System.out.println(name+"\t\t\t     " +r_no+ "\t\t\t\t\t" +chemistry+ "\t\t\t\t" +biology + "\t\t\t " +maths+ " \t\t\t" +total+ " \t\t\t" + percentage);
        System.out.println("*******************************************************************************************************************");

        // COUNTING GRADE HERE  //
        if (percentage >= 80) {
            System.out.println(name + " get A+ Grade");
        } else if (percentage >= 60) {
            System.out.println(name + " get A Grade");
        } else if (percentage >= 50) {
            System.out.println(name +" get B Grade");
        } else if (percentage >= 35) {
            System.out.println(name + " get C Grade");
        } else {
            System.out.println("Please enter valid input");
        }
        //    *****************       MAIN METHOD END HERE   ***************** //
    }
}

