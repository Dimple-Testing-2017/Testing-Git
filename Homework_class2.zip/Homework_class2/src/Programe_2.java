//    WAP to input any year like 1989 and find out if it is leap year    //

// FOR COUNTING LEAP YEAR WE NEED CALENDER CLASS //

import java.util.Calendar;
import java.util.Scanner;

import static java.util.Calendar.*;

public class Programe_2 {

public static void main(String args[])
{
     Scanner scanner = new Scanner(System.in);
     Calendar calendar = getInstance();
     int year;

      System.out.println("Please Enter any Year  -->");
      System.out.print(System.in);
      year = scanner.nextInt();

      // calender OBJECT GET THE VALUE FROM THE SYSTEM Calender //
   /* System.out.println(Calendar.JANUARY);
      System.out.println(Calendar.FEBRUARY);
      System.out.println("Year --> " + calendar.get(Calendar.YEAR));
      System.out.println("Today Date --> "+ calendar.get(Calendar.DATE));
      System.out.println("Week of the Year--> " + calendar.get(Calendar.WEEK_OF_YEAR));
      System.out.println("Day of the Month --> " + calendar.get(Calendar.DAY_OF_MONTH));
      System.out.println("Day of the Week--> " + calendar.get(Calendar.DAY_OF_WEEK));
      System.out.println("Hour of the Day--> " + calendar.get(Calendar.HOUR_OF_DAY));
      System.out.println("Local Time --> " +calendar.getTime());
      System.out.println("Month of the Year --> "+ calendar.get(Calendar.MONTH));
      System.out.println("February Month of the Year --> "+ Calendar.FEBRUARY);
   */

     // IT WILL SET THE YEAR IN SYSTEM CALENDER //
        calendar.set(Calendar.YEAR, year);

     // IT WILL GET MAXIMUM DAYS OF THE YEAR //
     // System.out.println(calendar.getActualMaximum(Calendar.DAY_OF_YEAR));

    if (calendar.getActualMaximum(Calendar.DAY_OF_YEAR) > 365)
     {
         System.out.println( year + " is Leap year.");
     }
     else
     {
        System.out.println(year +" is Not a Leap year.");
     }
}
}


