//  Input any two number and find out its odd or even (use if else )                //

import java.util.Scanner;

public class Programe_1 {


    //*************************  MAIN METHOD START FROM HERE ****************************//
    public static void main(String args[])
    {
        // VARIABLE DECLARATION  //
        int a,b;

        // ************   CREATING SCANNER CLASS OBJECT  *********** //
        Scanner scanner = new Scanner(System.in);

        // ASKING VALUE FROM USER //
        System.out.println("Please Enter any Number -->");
      //  System.out.print(System.in);

        // STORING VALUE GET FROM USER //
        a = scanner.nextInt();

        // IF STATEMENT FOR CHECKING CONDITION THAT NUMBER IS EVEN OR ODD //
        if(a % 2 == 0 )
        {
            System.out.println("The number enter by you is Even Number -->" + a );
        }
        else
        {
            System.out.println("The number enter by you is Odd Number  -->" +a);
        }

        // AFTER THIS STATEMENT IT WILL CLOSE THE SCANNER CLASS OBJECT SO NO MORE VALUE STORE IT WILL CLEAR BUFFER //
        //scanner.close();


    }
    //*************************  MAIN METHOD END HERE ****************************//

}
