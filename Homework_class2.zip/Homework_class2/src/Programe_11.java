/*  Input any alphabet in uppercase and print it in lowercase    */

import java.util.Scanner;
public class Programe_11 {

    // MAIN METHOOD DECLARATION //
    public static void main(String args[])
    {
        char c;
        String s,s1;

        // CREATING SCANNER CLASS OBJECT  //
        Scanner scanner = new Scanner(System.in);
        System.out.print(System.in);

        // GETTING ALPHABET VALUE FROM USER //
        System.out.println("Please enter any Capital Alphabet character here -->");
        s = scanner.next();

        /* GETTING FIRST CHARACTER FROM STRING BCOZ SCANNER CLASS DON'T HAVE ANY METHOD FOR GETTING CHARACTER VALUE FROM STRING SO WE ARE GETTING
           STRING VALUE FROM USER AND THEN GET FIRST CHARACTER FROM STRING          */
        //c = s.charAt(0);

        s1 = s.toLowerCase();
        //  IT CONVERT HOLE STRING INTO LOWER CASE THEN WE CAN GET FIRST CHARACTER  BCOZ TOLOWERCASE MWTHOD WORKS ONLY IN STRING NOT CHARACTER //
        c = s1.charAt(0);

        System.out.println("Converting Capital Alphabet character into Lower case is --> "+ c);

    }
    // MAIN METHOD END HERE //
}
