/*
WAP input sales id, seller's name, sales amount, salary basic and then find this sales
    commission
    sales amount >= 50,000 35% commission
    sales amount >= 30,000 20%
                          >= 20,000 10%
                          >= 10,000 5%
                         < 10,000 2%
 */
import java.util.Scanner;

public class Programe_9 {

    public static void main(String args[])
    {
         // VARIABLE DECLARATION HERE //
        int id;
        Double s_amount, s_basic,s_com=0.0,s_total =0.0;
        String name;

         // CREATING SCANNER CLASS OBJECT HERE AND GETTING VALUE FROM USER  //
          Scanner scanner = new Scanner(System.in);
          System.out.println(System.in);

          System.out.println("Please enter the Seller ID -->");
          id=scanner.nextInt();

          System.out.println("Please enter the Seller Name -->");
          name=scanner.next();

          System.out.println("Please enter the Salary Basic -->");
          s_basic=scanner.nextDouble();

         System.out.println("Please enter the Sales Amount -->");
         s_amount=scanner.nextDouble();

        // CHECKING SALES COMMISION ON BASIS OF SALES AMOUNT  //
        if(s_amount >= 50000)
         {
            s_com=s_basic / 35;
         }
          else if(s_amount >= 30000)
            {
                s_com=s_basic / 20;
            }
            else if(s_amount >= 20000)
             {
                 s_com = s_basic / 10;
             }
              else if(s_amount >= 10000)
               {
                  s_com = s_basic / 5;
               }
                else if(s_amount < 10000)
                {
                   s_com = s_basic / 2;
                 }

                 s_total = s_basic + s_com;

          System.out.println("Sales ID  \t\t Sales Name \t\t Salary Basic \t\t Sales Amount \t\t Sales Commision");
          System.out.println("------------------------------------------------------------------------------------------------");
          System.out.println(id +" \t\t\t\t  "+ name +" \t\t\t\t "+ s_basic +" \t\t\t "+ s_amount + " \t\t\t "+ s_total );



    }
}
